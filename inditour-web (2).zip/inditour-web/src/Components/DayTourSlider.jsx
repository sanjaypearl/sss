import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Navigation } from "swiper/modules";
import { Link } from "react-router-dom";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

const DayTourSlider = () => {
  const [tours, setTours] = useState([]);
  const [activeTab, setActiveTab] = useState("international"); // default
  const [activeDayRange, setActiveDayRange] = useState("1-3");

  // ✅ Day ranges with min & max values
  const dayRanges = [
    { key: "1-3", label: "1 to 3 days", min: 1, max: 3 },
    { key: "4-6", label: "4 to 6 days", min: 4, max: 6 },
    { key: "7-9", label: "7 to 9 days", min: 7, max: 9 },
    { key: "13-15", label: "13 to 15 days", min: 13, max: 15 },
    { key: "15+", label: "15 days or more", min: 15, max: 100 },
  ];

  useEffect(() => {
    fetch("${process.env.REACT_APP_BASE_URL}/tours")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setTours(data.data);
        }
      })
      .catch((err) => console.error("Error fetching tours:", err));
  }, []);

  const filteredTours = tours.filter((tour) => {
    const isInternational =
      tour.destination_type?.trim().toLowerCase() === "international";

    const matchesDestination =
      (activeTab === "international" && isInternational) ||
      (activeTab === "domestic" && !isInternational);

    const duration = tour.tour_duration[0];
    const range = dayRanges.find((r) => r.key === activeDayRange);
    const matchesDuration = duration >= range.min && duration <= range.max;

    return matchesDestination && matchesDuration;
  });

  return (
    <section className="day_tours">
      <div className="travel-container">
        <div className="travel-header">
          <h1>Explore best selling packages for</h1>

          {/* Tour type */}
          <div className="tabs">
            <button
              className={`tab-btn ${
                activeTab === "international" ? "active" : ""
              }`}
              onClick={() => setActiveTab("international")}
            >
              International Destinations
            </button>
            <button
              className={`tab-btn ${activeTab === "domestic" ? "active" : ""}`}
              onClick={() => setActiveTab("domestic")}
            >
              Destinations within India
            </button>
          </div>

          {/* Day Filters */}
          <div className="filters">
            {dayRanges.map((range) => (
              <button
                key={range.key}
                className={`filter-btn ${
                  activeDayRange === range.key ? "active" : ""
                }`}
                onClick={() => setActiveDayRange(range.key)}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>

        {/* Slider */}
        <div className="slider-wrap position-relative">
          {filteredTours.length > 0 ? (
            <Swiper
              modules={[Navigation, Pagination]}
              spaceBetween={20}
              slidesPerView={1}
              navigation={{
                nextEl: ".swiper-button-next-custom",
                prevEl: ".swiper-button-prev-custom",
              }}
              pagination={{
                clickable: true,
                el: ".swiper-pagination-custom",
                bulletClass: "custom-bullet",
                bulletActiveClass: "custom-bullet-active",
              }}
              breakpoints={{
                576: { slidesPerView: 2 },
                768: { slidesPerView: 3 },
                1024: { slidesPerView: 4 },
                1280: { slidesPerView: 4 },
              }}
            >
              {filteredTours.map((tour) => (
                <SwiperSlide key={tour.id}>
                  <Link to={`/trip-detail/${tour.id}`} className="text-dark">
                    <div className="card">
                      <div className="card-img">
                        <img
                          src={
                            tour.tour_images && tour.tour_images.length > 0
                              ? tour.tour_images[0].secure_url
                              : "/placeholder.svg"
                          }
                          alt={tour.tour_name}
                          draggable="false"
                        />
                        <div className="overlay"></div>
                        <div className="card-title mb-0">
                          <h3>{tour.tour_name}</h3>
                          <div className="d-flex justify-content-between align-items-center">
                            <p className="duration mb-0">
                              {tour.tour_duration[0]} {tour.tour_duration_type}
                            </p>
                            <span className="dest-type">
                              {tour.destination_type.trim()}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="card-content">
                        <span className="starting">Starting from</span>
                        <span className="price">₹{tour.original_price}</span>
                      </div>
                    </div>
                  </Link>
                </SwiperSlide>
              ))}
            </Swiper>
          ) : (
            <p className="no-tours">No tours available for this selection</p>
          )}
          <button className="swiper-button-prev-custom nav-btn">
            <svg className="icon" viewBox="0 0 24 24">
              <path
                d="M15 19l-7-7 7-7"
                stroke="currentColor"
                strokeWidth="2"
                fill="none"
              />
            </svg>
          </button>
          <button className="swiper-button-next-custom nav-btn">
            <svg className="icon" viewBox="0 0 24 24">
              <path
                d="M9 5l7 7-7 7"
                stroke="currentColor"
                strokeWidth="2"
                fill="none"
              />
            </svg>
          </button>
        </div>
        <div className="pagination-wrap">
          <div className="swiper-pagination-custom"></div>
        </div>
      </div>
    </section>
  );
};

export default DayTourSlider;
