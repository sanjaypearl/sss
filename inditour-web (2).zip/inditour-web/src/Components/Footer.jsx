import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <section className="rt-site-footer" data-scrollax-parent="true">
      {/* Background Shape */}
      <div
        className="rt-shape-emenetns-1"
        style={{
          backgroundImage:
            "url(https://server1.pearl-developer.com/inditour/public/front/assets/images/shape-elements/shape-4.png)",
        }}
        data-scrollax="properties: { translateY: '340px' }"
      ></div>

      {/* Footer Top */}
      <div
        className="footer-top rtbgprefix-cover"
        style={{
          backgroundImage:
            "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/footerbg.png')",
        }}
      >
        {/* Newsletter Section */}
        <div className="footer-subscripbe-box wow fade-in-bottom animated">
          <div className="container">
            <div className="row">
              <div className="col-xl-8 col-lg-10 mx-auto text-center">
                <div className="rt-section-title-wrapper text-white">
                  <h2 className="rt-section-title">
                    <span className="text-white">Newsletter</span>
                    Get The Latest News
                  </h2>
                  <p className="text-white">
                    Get the latest travel inspirations and deals from Indi Tour
                    semimonthly with your email. You can unsubscribe at any
                    time. Your privacy &amp; personal information will be
                    treated.
                  </p>
                </div>
              </div>
            </div>

            <div className="section-title-spacer"></div>

            {/* Newsletter Form */}
            <div className="row">
              <div className="col-lg-7 mx-auto">
                <div className="input-group mb-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter your email address"
                    aria-describedby="button-addon2"
                  />
                  <div className="input-group-append">
                    <button className="btn" type="button" id="button-addon2">
                      Subscribe Now
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="rt-dot-divider"></div>
          </div>
        </div>

        {/* Footer Links */}
        <div className="container">
          <div className="row">
            {/* Company Info */}
            <div className="col-lg-3 col-md-6">
              <div className="rt-single-widget wow fade-in-bottom animated">
                <h3 className="rt-footer-title">Company Info</h3>
                <ul className="rt-usefulllinks">
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <NavLink to="/about">About Us</NavLink>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>

                    <NavLink to="/contact-us">Contact Us</NavLink>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="/review">Customer Reviews</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="/privacy-policy">Privacy Policy</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="/term-condition">Term &amp; Condition</a>
                  </li>
                </ul>
              </div>
            </div>

            {/* Work With Us */}
            <div className="col-lg-3 col-md-6">
              <div className="rt-single-widget wow fade-in-bottom animated">
                <h3 className="rt-footer-title">Work With Us</h3>
                <ul className="rt-usefulllinks">
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Become Partner</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Careers</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Become Affiliate</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Associations</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Advertise with us</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Retirement Plan</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Travel APIs</a>
                  </li>
                </ul>
              </div>
            </div>

            {/* My Account */}
            <div className="col-lg-3 col-md-6">
              <div className="rt-single-widget wow fade-in-bottom animated">
                <h3 className="rt-footer-title">My Account</h3>
                <ul className="rt-usefulllinks">
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Manage Your Account</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Build your own trip</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Order Status</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Booking Guide</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Travel Insurance &amp; Safety Guide</a>
                  </li>
                </ul>
              </div>
            </div>

            {/* Plan Your Trip */}
            <div className="col-lg-3 col-md-6">
              <div className="rt-single-widget wow fade-in-bottom animated">
                <h3 className="rt-footer-title">Plan Your Trip</h3>
                <ul className="rt-usefulllinks">
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Special Offers</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Hotels</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Flights</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Tour Packages</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Accommodations</a>
                  </li>
                  <li>
                    <i class="fa-solid fa-chevron-right"></i>
                    <a href="#">Transportation</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="footer-bottom">
        <div className="container">
          <div className="row">
            {/* Copy Text */}
            <div className="col-lg-6 text-center text-lg-left">
              <div className="copy-text wow fade-in-bottom animated">
                2025 © All Rights Reserved &nbsp;
                <i className="fa fa-heart heart text-danger"></i>&nbsp; By{" "}
                <a
                  href="https://server1.pearl-developer.com/inditour/public"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Indi Tour
                </a>{" "}
                And Powered By{" "}
                <a
                  href="https://www.pearlorganisation.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Pearl Organisation
                </a>
              </div>
            </div>

            {/* Payment Icons */}
            <div className="col-lg-6 text-center text-lg-right">
              <div className="rt-footer-social wow fade-in-bottom animated">
                <ul>
                  <li>
                    <img
                      src="https://server1.pearl-developer.com/inditour/public/front/assets/images/brands/card-1.png"
                      alt="card"
                      draggable="false"
                    />
                  </li>
                  <li>
                    <img
                      src="https://server1.pearl-developer.com/inditour/public/front/assets/images/brands/card-2.png"
                      alt="card"
                      draggable="false"
                    />
                  </li>
                  <li>
                    <img
                      src="https://server1.pearl-developer.com/inditour/public/front/assets/images/brands/card-3.png"
                      alt="card"
                      draggable="false"
                    />
                  </li>
                  <li>
                    <img
                      src="https://server1.pearl-developer.com/inditour/public/front/assets/images/brands/card-4.png"
                      alt="card"
                      draggable="false"
                    />
                  </li>
                  <li>
                    <img
                      src="https://server1.pearl-developer.com/inditour/public/front/assets/images/brands/card-5.png"
                      alt="card"
                      draggable="false"
                    />
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Footer;
