import React, { useState } from 'react';

const BookingComponent = () => {
  const [step, setStep] = useState("button");
  const [selectedDate, setSelectedDate] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [bookingData, setBookingData] = useState({
    fullName: '',
    email: '',
    phone: '',
    guests: 1,
    message: ''
  });

  const handleBookClick = () => {
    setStep("calendar");
  };

  const handleDateClick = (date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (date < today) {
      alert('Please select a future date');
      return;
    }
    
    setSelectedDate(date);
    setStep("form");
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setBookingData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFormSubmit = () => {
    if (!bookingData.fullName || !bookingData.email || !bookingData.phone) {
      alert('Please fill in all required fields');
      return;
    }
    
    console.log('Booking enquiry submitted:', {
      ...bookingData,
      selectedDate: selectedDate?.toISOString(),
    });
    
    alert('Enquiry submitted successfully! We will contact you soon.');
    
    setStep("button");
    setSelectedDate(null);
    setBookingData({ fullName: '', email: '', phone: '', guests: 1, message: '' });
  };

  const closeModal = () => {
    setStep("button");
    setSelectedDate(null);
    setBookingData({ fullName: '', email: '', phone: '', guests: 1, message: '' });
  };

  // Calendar functions
  const getDaysInMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const goToPreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentMonth);
    const firstDay = getFirstDayOfMonth(currentMonth);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const days = [];
    const monthNames = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(
        <div key={`empty-${i}`} className="calendar-day empty"></div>
      );
    }

    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      const isPast = date < today;
      const isToday = date.toDateString() === today.toDateString();
      const isSelected = selectedDate && date.toDateString() === selectedDate.toDateString();

      days.push(
        <div
          key={day}
          className={`calendar-day ${isPast ? 'past' : 'available'} ${isToday ? 'today' : ''} ${isSelected ? 'selected' : ''}`}
          onClick={() => !isPast && handleDateClick(date)}
        >
          {day}
        </div>
      );
    }

    return (
      <div className="calendar-container">
        <div className="calendar-header">
          <button onClick={goToPreviousMonth} className="nav-button">
            &#8249;
          </button>
          <h3>{monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}</h3>
          <button onClick={goToNextMonth} className="nav-button">
            &#8250;
          </button>
        </div>
        
        <div className="calendar-weekdays">
          {dayNames.map(day => (
            <div key={day} className="weekday">{day}</div>
          ))}
        </div>
        
        <div className="calendar-grid">
          {days}
        </div>
      </div>
    );
  };

  return (
    <div>
      <style jsx>{`
        .booking-section {
          min-height: 100vh;
          display: flex;
        }
        
        .content-half {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          padding: 60px 40px;
          background: rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(10px);
        }
        
        .form-half {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          padding: 60px 40px;
          background: white;
        }
        
        .hero-image {
          width: 100%;
          max-width: 400px;
          height: 300px;
          object-fit: cover;
          border-radius: 20px;
          margin-bottom: 30px;
        }
        
        .enquiry-form {
          max-width: 95%;
          margin: 0 auto;
          width: 100%;
          box-shadow: 0 20px 40px rgb(193 193 193 / 30%);
          padding: 30px;
          border-radius: 20px;
        }
        
        .form-title {
          text-align: center;
          margin-bottom: 40px;
        }
        
        .form-title h2 {
          font-size: 2.5rem;
          color: #333;
          margin-bottom: 10px;
          font-weight: 700;
        }
        
        .form-title p {
          color: #666;
          font-size: 1.1rem;
        }
        
        .form-group {
          margin-bottom: 10px;
        }
        
        .form-label {
          display: block;
          margin-bottom: 5px;
          font-weight: 600;
          color: #333;
          font-size: 14px;
        }
        
        .form-input, .form-textarea {
          width: 100%;
          padding: 15px 20px;
          border: 2px solid #e0e0e0;
          border-radius: 12px;
          font-size: 16px;
          transition: all 0.3s ease;
          box-sizing: border-box;
        }
        
        .form-textarea {
          resize: vertical;
          min-height: 100px;
          font-family: inherit;
        }
        
        .form-input:focus, .form-textarea:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
          transform: translateY(-2px);
        }
        
        .date-display {
          background: linear-gradient(135deg, #667eea, #764ba2);
          color: white;
          padding: 15px 20px;
          border-radius: 12px;
          text-align: center;
          font-weight: 600;
          margin-bottom: 25px;
        }
        
        .btn {
          padding: 15px 30px;
          border: none;
          border-radius: 12px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          text-transform: uppercase;
          font-size: 14px;
          letter-spacing: 0.5px;
          width: 100%;
        }
        
        .btn-primary {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
        }
        
        .btn-primary:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
          background: #6c757d;
          color: white;
          margin-bottom: 15px;
        }
        
        .btn-secondary:hover {
          background: #545b62;
          transform: translateY(-2px);
        }
        
        .calendar-container {
          background: white;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        .calendar-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 20px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
        }
        
        .calendar-header h3 {
          margin: 0;
          font-size: 1.4rem;
          font-weight: 600;
        }
        
        .nav-button {
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          width: 40px;
          height: 40px;
          border-radius: 50%;
          font-size: 18px;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        
        .nav-button:hover {
          background: rgba(255, 255, 255, 0.3);
          transform: scale(1.1);
        }
        
        .calendar-weekdays {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          background: #f8f9fa;
        }
        
        .weekday {
          padding: 12px;
          text-align: center;
          font-weight: 600;
          color: #495057;
          font-size: 0.9rem;
        }
        
        .calendar-grid {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 1px;
          background: #e9ecef;
        }
        
        .calendar-day {
          aspect-ratio: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          background: white;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
          position: relative;
        }
        
        .calendar-day.empty {
          cursor: default;
          background: #f8f9fa;
        }
        
        .calendar-day.available:hover {
          background: #e3f2fd;
          transform: scale(1.1);
          z-index: 1;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        .calendar-day.past {
          color: #adb5bd;
          background: #f8f9fa;
          cursor: not-allowed;
        }
        
        .calendar-day.today {
          background: #fff3cd;
          color: #856404;
          font-weight: 700;
        }
        
        .calendar-day.selected {
          background: #667eea;
          color: white;
          font-weight: 700;
        }
        
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }
        
        .modal-content {
          background: white;
          border-radius: 15px;
          max-width: 90vw;
          max-height: 90vh;
          overflow: auto;
          position: relative;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .modal-header {
          text-align: center;
          padding: 30px 30px 20px;
          border-bottom: 1px solid #dee2e6;
        }
        
        .modal-header img {
          max-height: 60px;
          margin: 0 auto 10px;
        }
        
        .modal-header h4 {
          margin: 0 0 8px;
          color: #212529;
          font-weight: 600;
        }
        
        .modal-header p {
          margin: 0;
          color: #6c757d;
        }
        
        .modal-body {
          padding: 30px;
        }
        
        .close-button {
          position: absolute;
          top: 15px;
          right: 15px;
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          color: #6c757d;
          width: 30px;
          height: 30px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .close-button:hover {
          color: #000;
        }
        
        @media (max-width: 768px) {
          .booking-section {
            flex-direction: column;
            min-height: auto;
          }
          
          .content-half, .form-half {
            padding: 40px 20px;
          }
          
          .hero-content h1 {
            font-size: 2.5rem;
          }
          
          .form-title h2 {
            font-size: 2rem;
          }
          
          .modal-content {
            max-width: 95vw;
            margin: 20px;
          }
          
          .modal-header, .modal-body {
            padding: 20px;
          }
        }
      `}</style>
      
      <div className="booking-section">
        <div className="content-half">
          <img
            src="../assets/tal_to_us.png"
            alt="Beautiful travel destination"
            className="hero-image"
          />
          <div className="hero_content">
            <h3>Our experts would love to create a package just for you!</h3>
            <p>Fill in your requirements here </p>
          </div>
        </div>

        <div className="form-half">
          <div className="enquiry-form">
            <div className="form-title">
              <h2>Book Your Adventure</h2>
              <p>Fill out the form below to start planning your perfect getaway</p>
            </div>

            {selectedDate && (
              <div className="date-display">
                Selected Date: {selectedDate.toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
            )}

            <div className="form-group">
              <label className="form-label">Full Name *</label>
              <input
                type="text"
                name="fullName"
                value={bookingData.fullName}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter your full name"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Email Address *</label>
              <input
                type="email"
                name="email"
                value={bookingData.email}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter your email address"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Phone Number *</label>
              <input
                type="tel"
                name="phone"
                value={bookingData.phone}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter your phone number"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Number of Guests</label>
              <input
                type="number"
                name="guests"
                value={bookingData.guests}
                onChange={handleInputChange}
                className="form-input"
                min="1"
                max="20"
                placeholder="Number of guests"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Special Requests</label>
              <textarea
                name="message"
                value={bookingData.message}
                onChange={handleInputChange}
                className="form-textarea"
                placeholder="Any special requirements or questions..."
              />
            </div>
            
            {!selectedDate ? (
              <button onClick={handleBookClick} className="btn btn-primary">
                Select Travel Date
              </button>
            ) : (
              <div>
                <button onClick={() => setStep("calendar")} className="btn btn-secondary">
                  Change Date
                </button>
                <button onClick={handleFormSubmit} className="btn btn-primary">
                  Submit Enquiry
                </button>
              </div>
            )}
          </div>
        </div>

        {step === "calendar" && (
          <div className="modal-overlay">
            <div className="modal-content" style={{ width: '600px' }}>
              <div className="modal-header">
                <img
                  src="https://server1.pearl-developer.com/inditour/public/app/website-info/logo/indi-logo.png"
                  alt="modal logo"
                />
                
              </div>

              <div className="modal-body">
                {renderCalendar()}
              </div>

              <button className="close-button" onClick={closeModal}>
                ×
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BookingComponent;