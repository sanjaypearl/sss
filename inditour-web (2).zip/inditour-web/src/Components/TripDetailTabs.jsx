import React from 'react'

const TripDetailTabs = () => {
  return (
    <div>
      
    </div>
  )
}

export default TripDetailTabs
