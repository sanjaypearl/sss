import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Thumbs, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/thumbs";

const TripDetails = () => {
  const { id } = useParams();
  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  const [tour, setTour] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("inclusions");

  useEffect(() => {
    fetch(`https://indi-tour-backend.onrender.com/api/v1/tours/${id}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setTour(data.data);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching tour:", err);
        setLoading(false);
      });
  }, [id]);

  if (loading) return <p className="text-center">Loading...</p>;
  if (!tour) return <p className="text-center">No tour found.</p>;

  const tabData = [
    {
      id: "inclusions",
      label: "Inclusions",
      content: (
        <ul>
          {tour.inclusions.map((item, i) => (
            <li key={i}>✅ {item}</li>
          ))}
        </ul>
      ),
    },
    {
      id: "exclusions",
      label: "Exclusions",
      content: (
        <ul>
          {tour.exclusions.map((item, i) => (
            <li key={i}>❌ {item}</li>
          ))}
        </ul>
      ),
    },
    {
      id: "accommodation",
      label: "Accommodation",
      content: (
        <ul>
          {tour.accommodation.map((item, i) => (
            <li key={i}>🏨 {item}</li>
          ))}
        </ul>
      ),
    },
    {
      id: "transport",
      label: "Transport",
      content: (
        <ul>
          {tour.transport.map((item, i) => (
            <li key={i}>🚌 {item}</li>
          ))}
        </ul>
      ),
    },
    {
      id: "notice",
      label: "Notice",
      content: (
        <ul>
          {tour.notice.map((item, i) => (
            <li key={i}><i class="fa-regular fa-circle-check primary-color rt-pr-4"></i> {item}</li>
          ))}
        </ul>
      ),
    },
    {
      id: "itinerary",
      label: "Itinerary",
      content: (
        <div>
          {Object.keys(tour.itinerary).map((day, index) => (
            <div key={index} className="mb-3">
              <h6 className="fw-bold text-primary text-capitalize">{day}</h6>
              <ul>
                {tour.itinerary[day].map((step, i) => (
                  <li key={i}>
                    <strong>{step.time}</strong> – {step.activity}  
                    <br />
                    <small className="text-muted">{step.details}</small>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      ),
    },
  ];

  return (
    <section className="content-area">
      <div className="container">
        <div className="row">
          <div className="col-lg-7">
            <Swiper
              spaceBetween={10}
              navigation={true}
              thumbs={{ swiper: thumbsSwiper }}
              autoplay={{ delay: 4000 }}
              loop={true}
              modules={[Navigation, Thumbs, Autoplay]}
              className="rt-duel-slider-main"
            >
              {tour.tour_images.map((img, index) => (
                <SwiperSlide key={index}>
                  <div
                    className="single-main rtbgprefix-cover"
                    style={{
                      backgroundImage: `url(${img.secure_url})`,
                      width: "100%",
                      height: "400px",
                      backgroundSize: "cover",
                      backgroundPosition: "center",
                    }}
                  >
                    <div className="inner-badge badge-bg-1 f-size-14 rt-strong">
                      Last booked 12 mins ago
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>

            <Swiper
              onSwiper={setThumbsSwiper}
              spaceBetween={10}
              slidesPerView={4}
              watchSlidesProgress={true}
              modules={[Thumbs]}
              className="rt-duel-slider-thumb mt-3"
            >
              {tour.tour_images.map((img, index) => (
                <SwiperSlide key={index}>
                  <div
                    className="single--thumb rtbgprefix-cover"
                    style={{
                      backgroundImage: `url(${img.secure_url})`,
                      width: "100%",
                      height: "100px",
                      backgroundSize: "cover",
                      backgroundPosition: "center",
                      border: "1px solid #ddd",
                      borderRadius: "5px",
                    }}
                  ></div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>

          {/* Right: Info */}
          <div className="col-lg-5 mt-5 mt-lg-0">
            <div className="hotel-inner-content">
              <h5 className="f-size-18 rt-medium">{tour.tour_name}</h5>
              <p className="f-size-13 text-555">{tour.tour_caption}</p>

              <p className="rt-mt-15 rt-mb-20">
                <span className="badge rt-gradinet-badge pill rt-mr-10">
                  {tour.popularity_score / 20} <small>/5</small>
                </span>
                <span className="primary-color rt-mr-10">Excellent</span>
                <span className="f-size-12 text-878">( 86 Reviews )</span>
              </p>

              <h4 className="text-primary">
                ₹{tour.discounted_price.toLocaleString("en-IN")}{" "}
                <small className="text-muted f-size-12">per person</small>
              </h4>
              {tour.isDiscount && (
                <p>
                  <del>₹{tour.original_price.toLocaleString("en-IN")}</del>{" "}
                  <span className="text-danger">
                    {tour.discount_percent}% Off
                  </span>
                </p>
              )}
            </div>
          </div>
        </div>

        {/* ✅ Tabs Section */}
        <div className="row mt-5">
          <div className="col-12 rt-mt-58">
            <div className="hotel-tabs">
              <div className="flight-list-box rt-mb-40">
                <ul className="nav rt-tab-nav-1 pill pl-md-4 pr-md-4">
                  {tabData.map((tab) => (
                    <li key={tab.id} className="nav-item">
                      <a
                        className={`nav-link ${
                          activeTab === tab.id ? "active" : ""
                        }`}
                        onClick={() => setActiveTab(tab.id)}
                      >
                        {tab.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="tab-content">
                {tabData.map(
                  (tab) =>
                    activeTab === tab.id && (
                      <div
                        key={tab.id}
                        className="tab-pane active flight-list-box"
                      >
                        {tab.content}
                      </div>
                    )
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TripDetails;
