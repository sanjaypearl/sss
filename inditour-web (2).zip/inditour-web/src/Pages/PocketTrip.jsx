import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Autoplay, Navigation } from "swiper/modules";
import { Link } from "react-router-dom";

const PocketTrip = () => {
     const shortTour = [
  {
    title: "City Walking Tour",
    desc: "Explore the heart of the city with our guided walking tour. Discover hidden gems, local culture, and iconic landmarks in just a few hours.",
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
    time: "2 - 3 hours",
    price: "₹1999",
  },
  {
    title: "Heritage Site Visit",
    desc: "Step back in time with our heritage tour. Perfect for history lovers who want to experience the culture, architecture, and traditions of the past.",
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
    time: "3 - 4 hours",
    price: "₹2499",
  },
  {
    title: "Food & Market Experience",
    desc: "Taste the flavors of the city! Join our culinary and market tour to try street food, shop for souvenirs, and interact with locals.",
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
    time: "2 - 3.5 hours",
    price: "₹2999",
  },
  {
    title: "Nature Escape",
    desc: "Unwind in nature with a short hike or park visit. Breathe fresh air and enjoy the scenic beauty, away from the city hustle.",
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
    time: "1.5 - 3 hours",
    price: "₹2299",
  },
  {
    title: "Adventure Activity",
    desc: "For thrill-seekers, we offer short adventure activities like ziplining, ATV rides, or river rafting—perfect for an adrenaline rush.",
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
    time: "2 - 5 hours",
    price: "₹3999",
  },
];
  return (
    <>
      <div className="rt-breadcump rt-breadcump-height">
        <div
          className="rt-page-bg rtbgprefix-cover"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/bredcump.png')",
          }}
        ></div>
        <div className="container">
          <div className="row rt-breadcump-height">
            <div className="col-12">
              <div className="breadcrumbs-content">
                <h3>Short Trip</h3>
                <div className="breadcrumbs">
                  <span className="divider">
                    <i class="fa-solid fa-house"></i>
                  </span>
                  <a href="/" title="Home">
                    Home
                  </a>
                  <span className="divider">
                    <i class="fa-solid fa-chevron-right"></i>
                  </span>
                  Short Trip
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="bredcump--search-trip">
          <div className="container">
            <div className="row">
              <div className="col-lg-10 mx-auto">
                <div className="rt-banner-searchbox trip-search">
                  <div className="rt-input-group">
                    <div className="single-input col-md-8">
                      <input
                        type="text"
                        className="form-control _ad_input mr-3"
                        placeholder="Depart"
                      />
                      <span className="input-iconbadge">
                        <i className="fa-solid fa-location-dot input-iconbadge"></i>
                      </span>
                    </div>
                    <div className="single-input col-md-3 ms-3">
                      <input
                        type="submit"
                        value="Search"
                        className="rt-btn rt-gradient pill text-uppercase d-block rt-Bshadow-2 mr-3"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
        <section
          className="_ad_slide emigr-services-area rtbgprefix-contain travel_agency"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/dotbg.png')",
          }}
        >
          <div className="container">
            <div className="row">
              <div className="col-lg-8 text-center mx-auto">
                <div className="rt-section-title-wrapper">
                  <h2 className="rt-section-title">
                    Our Best-Selling Quick Escapes
                  </h2>
                </div>
              </div>
            </div>

            <div className="section-title-spacer"></div>

            <Swiper
              slidesPerView={3}
              spaceBetween={30}
              loop={true}
              autoplay={{
                delay: 2500,
                disableOnInteraction: false,
              }}
              navigation={true}
              breakpoints={{
                1400: { slidesPerView: 3 },
                1200: { slidesPerView: 3 },
                768: { slidesPerView: 2 },
                576: { slidesPerView: 1 },
              }}
              modules={[Navigation, Autoplay]}
              className="mySwiper short_tour_swiper"
            >
              {shortTour.map((item, index) => (
                <SwiperSlide key={index}>
                  <Link to="/trip-detail" className="text-dark">
                    <div className="services-box-1 text-center">
                      <div className="services-thumb">
                        <img
                          src={item.img}
                          alt={item.title}
                          draggable="false"
                        />
                      </div>
                      <h4>{item.title}</h4>
                      <p>{item.desc}</p>
                      <div className="d-flex align-items-center justify-content-between mt-2 w-100">
                        <p className="tour_time">{item.time}</p>
                        <p>
                          From <strong>{item.price}</strong> / Per Person
                        </p>
                      </div>
                    </div>
                  </Link>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </section>
    </>
  );
};

export default PocketTrip;
