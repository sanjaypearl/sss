import React from "react";

const BlogDetail = () => {
  return (
    <div className="blogdetail-page">
      <div className="blogdetail-hero">
        <div className="hero-overlay" />
        <img
          src="/himalayan-mountain-landscape-with-snow-peaks-and-v.jpg"
          alt="Himalayan landscape"
          className="hero-image"
        />
        <div className="hero-content">
          <div className="hero-tags">
            <span className="tag">Travel</span>
            <span className="tag">Adventure</span>
          </div>
          <h1 className="hero-title">Exploring the Beauty of the Himalayas</h1>
          <div className="hero-meta">
            <span>📅 September 12, 2025</span>
            <span>👤 Ashish Verma</span>
            <span>⏱ 8 min read</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="blogdetail-container">
        <div className="blogdetail-grid">
          {/* Article */}
          <article className="blogdetail-article">
            <p className="intro">
              The Himalayas are a treasure trove of natural beauty, cultural heritage, and thrilling adventures...
            </p>

            <p>
              From snow-capped peaks to lush valleys, the region offers breathtaking landscapes...
            </p>

            <p>
              Trekking in the Himalayas is a once-in-a-lifetime experience...
            </p>

            <blockquote className="quote">
              <p>
                "Traveling – it leaves you speechless, then turns you into a storyteller."
              </p>
              <cite>— Ibn Battuta</cite>
            </blockquote>

            <p>
              Apart from trekking, activities like river rafting, camping, and cultural tours make the Himalayas a
              complete destination...
            </p>
          </article>

          {/* Sidebar */}
          <aside className="blogdetail-sidebar">
            {/* TOC */}
            <div className="sidebar-card">
              <h3>Table of Contents</h3>
              <nav>
                <a href="#introduction">Introduction</a>
                <a href="#trekking">Trekking Adventures</a>
                <a href="#activities">Other Activities</a>
                <a href="#planning">Planning Your Trip</a>
              </nav>
            </div>

            {/* Share */}
            <div className="sidebar-card">
              <h3>Share this article</h3>
              <div className="share-buttons">
                <button>Twitter</button>
                <button>Facebook</button>
                <button>LinkedIn</button>
              </div>
            </div>
          </aside>
        </div>

        {/* Author */}
        <div className="author-card">
          <img
            src="https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-5.jpg"
            alt="Ashish Verma"
            className="author-img"
          />
          <div>
            <h3>Ashish Verma</h3>
            <p>
              Ashish is a passionate traveler and blogger who loves exploring hidden gems...
            </p>
            <div className="author-actions">
              <button>Follow</button>
              <button>More Articles</button>
            </div>
          </div>
        </div>

        {/* Related Posts */}
        <section className="related-posts">
          <h2>Related Articles</h2>
          <div className="related-grid">
            <div className="related-card">
              <img src="https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-5.jpg" alt="Beach" />
              <h3>Top 10 Beaches to Visit in 2025</h3>
              <p>Discover the most stunning beaches...</p>
              <span>📅 Sep 10, 2025</span>
            </div>

            <div className="related-card">
              <img src="https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-3.jpg" alt="Desert" />
              <h3>Exploring the Sahara Desert</h3>
              <p>An adventure through the world's largest hot desert...</p>
              <span>📅 Sep 8, 2025</span>
            </div>

            <div className="related-card">
              <img src="	https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-1.jpg" alt="City nightlife" />
              <h3>Best Nightlife Cities Around the World</h3>
              <p>Experience the vibrant nightlife scenes...</p>
              <span>📅 Sep 5, 2025</span>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default BlogDetail;
