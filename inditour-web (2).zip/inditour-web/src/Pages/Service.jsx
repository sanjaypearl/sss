import React from 'react'

const Service = () => {
  const services = [
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-5.png",
    title: "Air Ticketing",
    desc: "Our airport desk is conveniently located at the JKIA passenger terminal. We offer personalized meet and greet services at the airport. This helps fast track clearance through immigration and custom.",
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-6.png",
    title: "Hotel Bookings",
    desc: "Our airport desk is conveniently located at the JKIA passenger terminal. We offer personalized meet and greet services at the airport. This helps fast track clearance through immigration and custom.",
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-7.png",
    title: "Meet & Assist",
    desc: "Our airport desk is conveniently located at the JKIA passenger terminal. We offer personalized meet and greet services at the airport. This helps fast track clearance through immigration and custom.",
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-8.png",
    title: "Itinerary Planning",
    desc: "Our airport desk is conveniently located at the JKIA passenger terminal. We offer personalized meet and greet services at the airport. This helps fast track clearance through immigration and custom.",
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-9.png",
    title: "Adventure Travel",
    desc: "Our airport desk is conveniently located at the JKIA passenger terminal. We offer personalized meet and greet services at the airport. This helps fast track clearance through immigration and custom.",
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-10.png",
    title: "Business Travel",
    desc: "Our airport desk is conveniently located at the JKIA passenger terminal. We offer personalized meet and greet services at the airport. This helps fast track clearance through immigration and custom.",
  },
];
  return (
   <>
      <div className="rt-breadcump rt-breadcump-height">
        <div
          className="rt-page-bg rtbgprefix-cover"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/bredcump.png')",
          }}
        ></div>
        {/* /.rt-page-bg */}
        <div className="container">
          <div className="row rt-breadcump-height">
            <div className="col-12">
              <div className="breadcrumbs-content">
                <h3>Our Services</h3>
                <div className="breadcrumbs">
                  <span className="divider">
                    <i class="fa-solid fa-house"></i>
                  </span>
                  <a href="/" title="Home">
                    Home
                  </a>
                  <span className="divider">
                    <i class="fa-solid fa-chevron-right"></i>
                  </span>
                  Services
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <section className="svcPage-area">
      <div className="container">
        {/* Title */}
        <div className="row">
          <div className="col-lg-7 text-center mx-auto">
            <div className="rt-section-title-wrapper">
              <h2 className="rt-section-title">
                <span>Our Exclusive Offers</span>
                Our Services
              </h2>
              <p>
                We have the knowledge, experience, and expertise to take care of
                all your travel needs. Our Friendly and Professional staff can
                assist you with
              </p>
            </div>
          </div>
        </div>

        <div className="section-title-spacer"></div>

        {/* Service Cards */}
        <div className="row">
          {services.map((service, index) => (
            <div key={index} className="col-lg-4 col-md-6">
              <div
                className="rt-single-icon-box icon-center text-center justify-content-center wow fade-in-bottom animated"
                data-wow-duration={`${0.5 * (index + 1)}s`}
                style={{
                  visibility: "visible",
                  animationDuration: `${0.5 * (index + 1)}s`,
                  animationName: "fade-in-bottom",
                }}
              >
                <div className="icon-thumb">
                  <img src={service.img} alt={service.title} draggable="false" />
                </div>
                <div className="iconbox-content">
                  <h5>{service.title}</h5>
                  <p>{service.desc}</p>
                  <div className="read-morebtn">
                    <a href="#">
                      Read more <i class="fa-solid fa-arrow-right"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      </section>

      <section className="works3-area">
      <div className="rt-inner-overlay"></div>
      <div className="container">
        <div className="row">
          <div className="col-12 text-center">
            <div className="rt-section-title-wrapper">
              <h3>How we do</h3>
            </div>

            <div className="rt-box-style-1">
              <div className="row">
                {/* Card 1 */}
                <div className="col-lg-4 col-md-6">
                  <div className="rt-single-icon-box icon-center text-center justify-content-center wow fade-in-bottom animated">
                    <div className="icon-thumb">
                      <img
                        src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-11.png"
                        alt="Technology"
                        draggable="false"
                      />
                    </div>
                    <div className="iconbox-content">
                      <h5>Technology</h5>
                      <p>
                        In-house tools covering profile management, reporting
                        and more
                      </p>
                    </div>
                  </div>
                </div>

                {/* Card 2 */}
                <div className="col-lg-4 col-md-6">
                  <div className="rt-single-icon-box icon-center text-center justify-content-center wow fade-in-bottom animated">
                    <div className="icon-thumb">
                      <img
                        src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-12.png"
                        alt="Global Agency"
                        draggable="false"
                      />
                    </div>
                    <div className="iconbox-content">
                      <h5>Global Agency</h5>
                      <p>
                        100+ trusted, reputable local agencies in 72 markets on
                        6 continents
                      </p>
                    </div>
                  </div>
                </div>

                {/* Card 3 */}
                <div className="col-lg-4 col-md-6">
                  <div className="rt-single-icon-box icon-center text-center justify-content-center wow fade-in-bottom animated">
                    <div className="icon-thumb">
                      <img
                        src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-13.png"
                        alt="Leadership Team"
                        draggable="false"
                      />
                    </div>
                    <div className="iconbox-content">
                      <h5>Leadership Team</h5>
                      <p>
                        Passionate about business travel, with decades of
                        multi-industry experience
                      </p>
                    </div>
                  </div>
                </div>

                {/* Button */}
                <div className="col-12 text-center">
                  <a
                    href="#"
                    className="rt-btn rt-gradient rt-Bshadow-2 rt-rounded rt-sm text-uppercase"
                  >
                    Find Out More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </section>
      <div class="spacer-top"></div>

      <section className="about-area2">
      <div
        className="rt-design-elmnts rtbgprefix-contain"
        style={{
          backgroundImage: "url(assets/images/all-img/abt_vec_3.png)",
        }}
      ></div>
      <div className="container">
        <div className="row">
          <div className="col-lg-7">
            <div className="rt-section-title-wrapper">
              <h2 className="rt-section-title">
                <span>Extraordinary experiences,</span>
                Customize Your Tour
              </h2>
              <p>
                At Emigrar, we excel at helping you get your vacation planned.
                Not just any vacation, but exceptional vacations filled with
                inspiring and life-enriching experiences. <br />
                Our approach is different. We don’t plan any trips ourselves.
                Instead, we match you with 2 or 3 leading travel specialists who
                are the most qualified to make your dream trip happen. They then
                compete to design your ideal itinerary.
              </p>
            </div>
            <div className="section-title-spacer"></div>
            <a
              href="#"
              className="rt-btn rt-primary rt-rounded"
            >
              Get Matched to Travel Specialists
            </a>
          </div>
        </div>
      </div>
    </section>
   </>
  )
}

export default Service
