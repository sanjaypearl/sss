import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import DatePicker from "react-datepicker";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Thumbs, Autoplay } from "swiper/modules";
import { Modal, Button } from "react-bootstrap";
import TourEnquiryForm from "../Components/BookingForm";

import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/thumbs";
import "react-datepicker/dist/react-datepicker.css";

const TripDetails = () => {
  const { id } = useParams();

  // Hooks MUST be top-level (not conditional)
  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  const [tour, setTour] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [show, setShow] = useState(false);
  const [user, setUser] = useState(null);
  const [amount, setAmount] = useState(0);
const [tourId, setTourId] = useState();
  const handleOpen = (data) =>{ 
    setTourId(data?.id);
    setAmount(data?.discounted_price);
    setShow(true)};
  const handleClose = () => setShow(false);
  useEffect(() => {
    // localStorage se data get karo
    const storedUser = localStorage.getItem("user");

    if (storedUser) {
      try {
        // parse karke state me set
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error("Error parsing user data from localStorage:", error);
      }
    }
  }, []);
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const res = await fetch(
          `${process.env.REACT_APP_BASE_URL}/tours/${id}`
        );
        if (!res.ok) throw new Error("Network response not ok");

        const json = await res.json();
        // API sometimes returns data as array or object. handle both.
        let t = json?.data ?? null;
        if (Array.isArray(t)) t = t.length ? t[0] : null;
        if (mounted) setTour(t);
      } catch (err) {
        if (mounted) setError(err.message || "Failed to fetch");
      } finally {
        if (mounted) setLoading(false);
      }
    })();

    return () => {
      mounted = false;
    };
  }, [id]);

  if (loading) return <p className="text-center">Loading...</p>;
  if (error) return <p className="text-center">Error: {error}</p>;
  if (!tour) return <p className="text-center">No tour found.</p>;

  // Helper to safely get an array from itinerary entry
  const getStepsArray = (maybe) => {
    if (!maybe) return [];
    if (Array.isArray(maybe)) return maybe;
    // if it's an object (rare), take its values as an array
    if (typeof maybe === "object") return Object.values(maybe);
    return [];
  };

  const tabData = [
    {
      id: "overview",
      label: "Overview",
      content: (
        <>
          <h4 className="badge-hilighit color--1 f-size-14 text-white text-uppercase rt-mb-30 rt-mt-15 rt-strong">
            HIGHLIGHTS
          </h4>
          {tour.tour_highlights?.length ? (
            tour.tour_highlights.map((h, i) => <p key={i}>{h}</p>)
          ) : (
            <p>No highlights available.</p>
          )}
        </>
      ),
    },
    {
      id: "itenary",
      label: "Itinerary",
      content: (
        <div className="_ad_itenary">
          <div className="list">
            {Object.keys(tour.itinerary || {}).length === 0 ? (
              <p>No itinerary available.</p>
            ) : (
              Object.keys(tour.itinerary).map((dayKey, index) => {
                const steps = getStepsArray(tour.itinerary[dayKey]);
                return (
                  <div key={dayKey} className="mb-3">
                    <h5 className="_ad_day_head">
                      {dayKey.replace(
                        /([a-zA-Z]+)/,
                        (m) => m.charAt(0).toUpperCase() + m.slice(1)
                      )}
                    </h5>

                    {steps.length === 0 ? (
                      <p>No details for this day.</p>
                    ) : (
                      steps.map((step, i) => (
                        <div key={i} className="list__item mb-3">
                          <div className="list__time">{step.time}</div>
                          <div className="list__desc">
                            <h3>{step.activity}</h3>
                            <p>{step.details}</p>
                            <div className="border" />
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      ),
    },
    {
      id: "service",
      label: "Services",
      content: (
        <div>
          <h4 className="f-siz-18 rt-pt-10 rt-semiblod text-uppercase rt-mb-15">
            WHAT’S INCLUDED
          </h4>

          <h5 className="f-size-16 rt-mt-10">ACCOMMODATION</h5>
          {tour.accommodation?.length ? (
            tour.accommodation.map((acc, i) => <p key={i}>{acc}</p>)
          ) : (
            <p>Not specified</p>
          )}

          <h5 className="f-size-16 rt-mt-10">TRANSPORT</h5>
          {tour.transport?.length ? (
            tour.transport.map((tr, i) => <p key={i}>{tr}</p>)
          ) : (
            <p>Not specified</p>
          )}

          <h5 className="f-size-16 rt-mt-10">Include Activities</h5>
          <ul className="list-unstyled ps-3">
            {tour.inclusions?.length ? (
              tour.inclusions.map((inc, i) => (
                <li key={i}>
                  <i className="fa-solid fa-check me-2" /> {inc}
                </li>
              ))
            ) : (
              <li>Not specified</li>
            )}
          </ul>
        </div>
      ),
    },
    {
      id: "include",
      label: "Include (Day-wise)",
      content: (
        <div>
          {Object.keys(tour.itinerary || {}).map((dayKey, idx) => {
            const steps = getStepsArray(tour.itinerary[dayKey]);
            return (
              <div key={dayKey} className="trip-timeline rt-list mb-4">
                <div className="time-line-item list-unstyled flight-list-box">
                  <div className="timeline-counter">
                    <div className="inner-item d-flex align-items-center gap-2 mb-3">
                      <h3 className="d-block f-size-24 rt-strong">
                        Day {idx + 1}
                      </h3>
                    </div>
                  </div>

                  <div className="timeline-content">
                    {steps.map((step, i) => (
                      <div key={i} className="mb-3">
                        <h4 className="f-size-18 rt-semiblod rt-mb-10">
                          <span className="f-size-14 d-block rt-mb-5">
                            {step.time}
                          </span>
                          {step.activity}
                        </h4>
                        <p className="f-size-16 rt-strong">{step.details}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ),
    },
    {
      id: "notice",
      label: "Notice",
      content: (
        <div>
          <h4 className="f-size-18 rt-semiblod rt-mb-35">Notice</h4>
          {tour.notice?.length ? (
            <ul className="list-unstyled">
              {tour.notice.map((n, i) => (
                <li key={i}>{n}</li>
              ))}
            </ul>
          ) : (
            <p>No notices.</p>
          )}
        </div>
      ),
    },
  ];

  return (
    <>
      <div className="rt-breadcump rt-breadcump-height">
        <div
          className="rt-page-bg rtbgprefix-cover"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/bredcump.png')",
          }}
        ></div>
        <div className="container">
          <div className="row rt-breadcump-height">
            <div className="col-12">
              <div className="breadcrumbs-content">
                <h3>Package Details</h3>
                <div className="breadcrumbs">
                  <span className="divider">
                    <i class="fa-solid fa-house"></i>
                  </span>
                  <a href="/" title="Home">
                    Home
                  </a>
                  <span className="divider">
                    <i class="fa-solid fa-chevron-right"></i>
                  </span>
                  Package Details
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="bredcump--search-trip">
          <div className="container">
            <div className="row">
              <div className="col-lg-10 mx-auto">
                <div className="rt-banner-searchbox trip-search">
                  <div className="rt-input-group">
                    <div className="single-input col-md-8">
                      <input
                        type="text"
                        className="form-control _ad_input mr-3"
                        placeholder="Depart"
                      />
                      <span className="input-iconbadge">
                        <i className="fa-solid fa-location-dot input-iconbadge"></i>
                      </span>
                    </div>
                    <div className="single-input col-md-3 ms-3">
                      <input
                        type="submit"
                        value="Search"
                        className="rt-btn rt-gradient pill text-uppercase d-block rt-Bshadow-2 mr-3"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="content-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-7">
              <Swiper
                spaceBetween={10}
                navigation={true}
                thumbs={{ swiper: thumbsSwiper }}
                autoplay={{ delay: 4000 }}
                loop={true}
                modules={[Navigation, Thumbs, Autoplay]}
                className="rt-duel-slider-main"
              >
                {tour.tour_images.map((img, index) => (
                  <SwiperSlide key={index}>
                    <div
                      className="single-main rtbgprefix-cover"
                      style={{
                        backgroundImage: `url(${img.secure_url})`,
                        width: "100%",
                        height: "400px",
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                      }}
                    >
                      <div className="inner-badge badge-bg-1 f-size-14 rt-strong">
                        Last booked 12 mins ago
                      </div>
                    </div>
                  </SwiperSlide>
                ))}
              </Swiper>

              <Swiper
                onSwiper={setThumbsSwiper}
                spaceBetween={10}
                slidesPerView={4}
                watchSlidesProgress={true}
                modules={[Thumbs]}
                className="rt-duel-slider-thumb mt-3"
              >
                {tour.tour_images.map((img, index) => (
                  <SwiperSlide key={index}>
                    <div
                      className="single--thumb rtbgprefix-cover"
                      style={{
                        backgroundImage: `url(${img.secure_url})`,
                        width: "100%",
                        height: "100px",
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        border: "1px solid #ddd",
                        borderRadius: "5px",
                      }}
                    ></div>
                  </SwiperSlide>
                ))}
              </Swiper>
            </div>

            <div className="col-lg-5 mt-5 mt-lg-0">
              <div className="hotel-inner-content">
                <h5 className="f-size-18 rt-medium">{tour.tour_name}</h5>
                <p className="f-size-13 text-555">{tour.tour_caption}</p>

                <p className="rt-mt-15 rt-mb-20">
                  <span className="badge rt-gradinet-badge pill rt-mr-10">
                    {tour.popularity_score / 20} <small>/5</small>
                  </span>
                  <span className="primary-color rt-mr-10">Excellent</span>
                  <span className="f-size-12 text-878">( 86 Reviews )</span>
                </p>

                <div class="rt-divider style-one rt-mt-30"></div>
                <div className="rt-mt-25"></div>

                <div className="d-flex align-items-center gap-3 rt-mb-20 justify-content-between">
                  <div className="d-flex flex-column">
                    {tour.original_price && (
                      <p className="mb-0">
                        <del>
                          ₹{tour.original_price.toLocaleString("en-IN")}
                        </del>{" "}
                        <span className="text-danger">
                          {tour.discount_percent}% Off
                        </span>
                      </p>
                    )}
                    <h4 className="text-primary">
                      ₹{tour.discounted_price}{" "}
                      <small className="text-muted f-size-12">per person</small>
                    </h4>
                  </div>
                  <button class="rt-btn rt-gradient rt-sm2 text-uppercase pill" onClick={()=>handleOpen(tour)}>
                    Book Now
                  </button>
                </div>

                <div class="rt-divider style-one rt-mt-30"></div>

                <div className="rt-mt-25">
                  {" "}
                  <ul className="rt-social normal-style-one justify-content-start">
                    {" "}
                    <li>
                      {" "}
                      <span className="f-size-14 profile_content">
                        {" "}
                        <img
                          src="https://cdn-icons-png.flaticon.com/128/3135/3135715.png"
                          alt="Profile"
                        />{" "}
                        <strong>Ashish Verma</strong>{" "}
                      </span>{" "}
                    </li>{" "}
                    <li>
                      {" "}
                      <a href="#">
                        {" "}
                        <i className="fab fa-facebook"></i>{" "}
                      </a>{" "}
                    </li>{" "}
                    <li>
                      {" "}
                      <a href="#">
                        {" "}
                        <i className="fab fa-whatsapp"></i>{" "}
                      </a>{" "}
                    </li>{" "}
                    <li>
                      {" "}
                      <a href="#">
                        {" "}
                        <i className="fas fa-envelope"></i>{" "}
                      </a>{" "}
                    </li>{" "}
                    <li>
                      {" "}
                      <a href="#">
                        {" "}
                        <i className="fas fa-phone"></i>{" "}
                      </a>{" "}
                    </li>{" "}
                  </ul>{" "}
                </div>
              </div>
            </div>
          </div>

          {/* ✅ Tabs Section */}
          <div className="row mt-5">
            <div className="col-12 rt-mt-58">
              <div className="hotel-tabs">
                <div className="flight-list-box rt-mb-40">
                  <ul className="nav rt-tab-nav-1 pill pl-md-4 pr-md-4">
                    {tabData.map((tab) => (
                      <li key={tab.id} className="nav-item">
                        <a
                          className={`nav-link ${
                            activeTab === tab.id ? "active" : ""
                          }`}
                          onClick={() => setActiveTab(tab.id)}
                        >
                          {tab.label}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="tab-content">
                  {tabData.map(
                    (tab) =>
                      activeTab === tab.id && (
                        <div
                          key={tab.id}
                          className="tab-pane active flight-list-box"
                        >
                          {tab.content}
                        </div>
                      )
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {show && (
        <div
          className="modal fade show"
          style={{ display: "block", background: "rgba(0,0,0,0.6)" }}
          tabIndex="-1"
        >
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Book Your Tour</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={handleClose}
                ></button>
              </div>
              <div className="modal-body">
                <TourEnquiryForm data={user} tourId={tourId} amount={amount}/>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default TripDetails;
