import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./Components/Header";

import Home from "./Pages/Home";
import TripPackage from "./Pages/TripPackage";
import Service from "./Pages/Service";
import About from "./Pages/About";
import Blog from "./Pages/Blog";
import Contact from "./Pages/Contact";
import Footer from "./Components/Footer";
import PocketTrip from "./Pages/PocketTrip";
import "./index.css";
import "./App.css";
import 'swiper/css';
import 'swiper/css/pagination';
import "swiper/css/navigation";
import TripDetails from "./Pages/TripDetails";
import BlogDetail from "./Pages/BlogDetail";

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/trip-package" element={<TripPackage />} />
        <Route path="/service" element={<Service />} />
        <Route path="/about" element={<About />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/contact-us" element={<Contact />} />
        <Route path="/trip-detail/:id" element={<TripDetails />} />
        <Route path="/pocket-trips" element={<PocketTrip />} />
        <Route path="/blog-detail" element={<BlogDetail />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
