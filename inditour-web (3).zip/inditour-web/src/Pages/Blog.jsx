import React from 'react'

const Blog = () => {

  const blogPosts = [
    {
      id: 1,
      // img: "assets/images/all-img/mpost-1.jpg",
      date: "22",
      month: "Dec",
      title: "Elements of a Strong Corporate Travel Program",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "1s",
    },
    {
      id: 2,
      // img: "assets/images/all-img/mpost-2.jpg",
      date: "22",
      month: "Dec",
      title: "Closer To Truth: Is Time Travel Possible?",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "1.5s",
    },
    {
      id: 3,
      // img: "assets/images/all-img/mpost-3.jpg",
      date: "22",
      month: "Dec",
      title: "Travel Risk Management and Foreseeable Risk",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "2s",
    },
    {
      id: 4,
      // img: "assets/images/all-img/mpost-4.jpg",
      date: "22",
      month: "Dec",
      title: "How to Become a Group Leader and Travel Free",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "2.5s",
    },
    {
      id: 5,
      // img: "assets/images/all-img/mpost-5.jpg",
      date: "22",
      month: "Dec",
      title: "Best Traveling Experience at Affordable Cost",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "2s",
    },
    {
      id: 6,
      // img: "assets/images/all-img/mpost-6.jpg",
      date: "22",
      month: "Dec",
      title: "Is There a Travel Consultant on Your Team?",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "2s",
    },
    {
      id: 7,
      // img: "assets/images/all-img/mpost-7.jpg",
      date: "22",
      month: "Dec",
      title: "A Short Note About the Variety of Travellers",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "3s",
    },
    {
      id: 8,
      // img: "assets/images/all-img/mpost-8.jpg",
      date: "22",
      month: "Dec",
      title: "Travelings Commandments of Wise Travel",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "2s",
    },
    {
      id: 9,
      // img: "assets/images/all-img/mpost-9.jpg",
      date: "22",
      month: "Dec",
      title: "The Health Benefits of Humor When Traveling",
      comments: 20,
      views: 466,
      desc: "This article will give you the basic points to consider when putting together or revamping your corporate travel.",
      link: "#",
      duration: "3s",
    },
  ];

  return (
    <>
      <div className="rt-breadcump rt-breadcump-height">
        <div
          className="rt-page-bg rtbgprefix-cover"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/bredcump.png')",
          }}
        ></div>
        {/* /.rt-page-bg */}
        <div className="container">
          <div className="row rt-breadcump-height">
            <div className="col-12">
              <div className="breadcrumbs-content">
                <h3>Blogs</h3>
                <div className="breadcrumbs">
                  <span className="divider">
                    <i class="fa-solid fa-house"></i>
                  </span>
                  <a href="/" title="Home">
                    Home
                  </a>
                  <span className="divider">
                    <i class="fa-solid fa-chevron-right"></i>
                  </span>
                  Blogs
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="blog-content-area">
      <div className="container">
        <div className="row">
          {blogPosts.map((post) => (
            <div className="col-lg-4 col-sm-6 mx-auto" key={post.id}>
              <article
                className="single-blg-post grid-view standard-post wow fadeInUp animated"
                data-wow-duration={post.duration}
              >
                <a href={post.link} className="post-thumbnail">
                  {/* <img src={post.img} alt={post.title} /> */}
                  <div className="meta-date">
                    <span>{post.date}</span>
                    <span>{post.month}</span>
                  </div>
                </a>
                <div className="entry-content">
                  <header className="entry-header">
                    <h2 className="entry-title">
                      <a href={post.link} rel="bookmark">
                        {post.title}
                      </a>
                    </h2>
                    <div className="entry-meta">
                      <span>
                        <a href={post.link}>
                          <i class="fa-solid fa-comments me-2"></i>
                          {post.comments} Comments
                        </a>
                      </span>
                      <span>
                        <a href={post.link}>
                          <i class="fa-solid fa-eye-slash me-2"></i>
                          {post.views} View
                        </a>
                      </span>
                    </div>
                  </header>
                  <p>{post.desc}</p>
                  <footer className="entry-footer text-center">
                    <a href={post.link}>read more</a>
                  </footer>
                </div>
              </article>
            </div>
          ))}

        </div>
      </div>
    </div>
    </>
  )
}

export default Blog
