import Testimonials from "../Components/Testimonials";
const About = () => {
  return (
    <>
      <div className="rt-breadcump rt-breadcump-height">
        <div
          className="rt-page-bg rtbgprefix-cover"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/bredcump.png')",
          }}
        ></div>
        {/* /.rt-page-bg */}
        <div className="container">
          <div className="row rt-breadcump-height">
            <div className="col-12">
              <div className="breadcrumbs-content">
                <h3>About Us</h3>
                <div className="breadcrumbs">
                  <span className="divider">
                    <i class="fa-solid fa-house"></i>
                  </span>
                  <a href="/" title="Home">
                    Home
                  </a>
                  <span className="divider">
                    <i class="fa-solid fa-chevron-right"></i>
                  </span>
                  About Us
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <section className="about-area">
        <div
          className="rt-design-elmnts rtbgprefix-contain"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/abt_vec_2.png')",
          }}
        ></div>
        <div className="container">
          <div className="row">
            <div className="col-xl-9 offset-xl-3">
              <div className="rt-section-title-wrapper">
                <h2 className="rt-section-title">
                  <span>Our Short Story</span>
                  Know About Emigrar
                </h2>
                {/* /.rt-section-title */}
                <p>
                  Our aim is to make global corporate travel management more
                  personalized and seamless. And we do this through a network of
                  exceptional local agencies that are not only leaders in their
                  own respective markets, but who also meet the high operating and
                  service standards needed to become a Radius member. <br />
                  we specialize in vacation packages, escorted and independent
                  tour packages, cruises, honeymoons, weddings at foreign
                  locations, and corporate travel. Our staff is dedicated to
                  connecting our customers with amazing travel experiences around
                  the world, all at a price that suits their needs. We will
                  happily work with you to plan your dream vacation or corporate
                  trip that meets both your budget and experience goals, whatever
                  they may be!
                </p>
              </div>
              {/* /.rt-section-title-wrapper */}

              <div className="section-title-spacer"></div>

              <div className="row">
                <div className="col-lg-3 col-md-4 mx-auto col-sm-6 text-center">
                  <div
                    className="counter-box-2 wow fadeInUp animated"
                    style={{ visibility: "visible", animationName: "fadeInUp" }}
                  >
                    <div className="counter-thumb">
                      <img
                        src="https://server1.pearl-developer.com/inditour/public/front/assets/images/counter-icons/counter_iocn_4.png"
                        alt="counter"
                        draggable="false"
                      />
                    </div>
                    <h5>
                      <span className="counter">10</span>
                    </h5>
                    <h6>Years Experience</h6>
                  </div>
                </div>

                <div className="col-lg-3 col-md-4 mx-auto col-sm-6 text-center">
                  <div
                    className="counter-box-2 wow fadeInUp animated"
                    style={{
                      visibility: "visible",
                      animationDuration: "1.5s",
                      animationName: "fadeInUp",
                    }}
                  >
                    <div className="counter-thumb">
                      <img
                        src="https://server1.pearl-developer.com/inditour/public/front/assets/images/counter-icons/counter_iocn_5.png"
                        alt="counter"
                        draggable="false"
                      />
                    </div>
                    <h5>
                      <span className="counter">120</span>
                    </h5>
                    <h6>Worldwide Coverage</h6>
                  </div>
                </div>

                <div className="col-lg-3 col-md-4 mx-auto col-sm-6 text-center">
                  <div
                    className="counter-box-2 wow fadeInUp animated"
                    style={{
                      visibility: "visible",
                      animationDuration: "2s",
                      animationName: "fadeInUp",
                    }}
                  >
                    <div className="counter-thumb">
                      <img
                        src="https://server1.pearl-developer.com/inditour/public/front/assets/images/counter-icons/counter_iocn_6.png"
                        alt="counter"
                        draggable="false"
                      />
                    </div>
                    <h5>
                      <span className="counter">550</span>
                    </h5>
                    <h6>Tour Operators</h6>
                  </div>
                </div>

                <div className="col-lg-3 col-md-4 mx-auto col-sm-6 text-center">
                  <div
                    className="counter-box-2 wow fadeInUp animated"
                    style={{
                      visibility: "visible",
                      animationDuration: "2.5s",
                      animationName: "fadeInUp",
                    }}
                  >
                    <div className="counter-thumb">
                      <img
                        src="https://server1.pearl-developer.com/inditour/public/front/assets/images/counter-icons/counter_iocn_7.png"
                        alt="counter"
                        draggable="false"
                      />
                    </div>
                    <h5>
                      <span className="counter">2,500</span>
                    </h5>
                    <h6>Cities available</h6>
                  </div>
                </div>
              </div>
              {/* /.row */}
            </div>
          </div>
        </div>
      </section>
      <div class="spacer-top"></div>

      <section className="book-area">
        <div
          className="rt-design-elmnts rtbgprefix-contain"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/abt_vec_1.png')",
          }}
        ></div>
        {/* /.rt-design-elmnts */}
        <div className="container">
          <div className="row">
            <div className="col-lg-7">
              <div className="rt-section-title-wrapper">
                <h2 className="rt-section-title">
                  <span>How We're Different</span>
                  Why Book With Us?
                </h2>
                <p>
                  OTA's (Online Travel Agents) have dominated the market for over
                  10 years giving consumers headaches for years by attaching
                  hidden fees, giving you a false sense of savings where there
                  really is none due to the OTA agreements that are in place to
                  make sure these companies can never compete against each other,
                  and the use of predictive analytics to boost rates on your
                  vacation based on how many times you search for a specific flight
                  or click on a link.
                </p>
              </div>
              {/* /.rt-section-title-wrapper */}

              <div className="section-title-spacer"></div>

              {/* Box 1 */}
              <div className="rt-single-icon-box wow fade-in-bottom animated">
                <div className="icon-thumb">
                  <img
                    src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-1.png"
                    alt="box-icon"
                    draggable="false"
                  />
                </div>
                <div className="iconbox-content">
                  <h5>+350,000 Hotels</h5>
                  <p>
                    Pick from a wide array of an ever-growing list of hotels in
                    popular destinations (Over 14 million hotel rooms).
                  </p>
                </div>
              </div>

              {/* Box 2 */}
              <div
                className="rt-single-icon-box wow fade-in-bottom animated"
                data-wow-duration="1.5s"
              >
                <div className="icon-thumb">
                  <img
                    src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-2.png"
                    alt="box-icon"
                    draggable="false"
                  />
                </div>
                <div className="iconbox-content">
                  <h5>World Wide Tour Operators</h5>
                  <p>
                    The six continents are open for the adventures of a lifetime.
                    Go anywhere, any place, anytime..
                  </p>
                </div>
              </div>

              {/* Box 3 */}
              <div
                className="rt-single-icon-box wow fade-in-bottom animated"
                data-wow-duration="2s"
              >
                <div className="icon-thumb">
                  <img
                    src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-3.png"
                    alt="box-icon"
                    draggable="false"
                  />
                </div>
                <div className="iconbox-content">
                  <h5>Access to 9,300 Private Resorts</h5>
                  <p>
                    Giving you access to the world's most luxurious members only
                    resorts. Go anywhere, any place, anytime.
                  </p>
                </div>
              </div>

              {/* Box 4 */}
              <div
                className="rt-single-icon-box wow fade-in-bottom animated"
                data-wow-duration="2.5s"
              >
                <div className="icon-thumb">
                  <img
                    src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/box-icon-4.png"
                    alt="box-icon"
                    draggable="false"
                  />
                </div>
                <div className="iconbox-content">
                  <h5>All major Cruise Lines</h5>
                  <p>
                    Glide through the waters of the five oceans, river cruises and
                    luxury cruises.
                  </p>
                </div>
              </div>
            </div>
            {/* /.col-lg-7 */}
          </div>
        </div>
      </section>
      <div class="spacer-bottom"></div>

      <section className="rt-cta-area">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="cta-box-2 d-flex flex-column align-items-center justify-content-center bg-gradient-primary">
                <div className="row">
                  <div className="col-lg-7 mx-auto">
                    <div className="rt-section-title-wrapper text-white text-center">
                      <h2 className="rt-section-title">
                        <span className='text-white'>Save Time, Save Money</span>
                        Let’s Get Started
                      </h2>
                      <p className='text-white'>
                        We have the knowledge, experience, and expertise to take
                        care of all your travel needs. Sign up and we'll send the
                        best deals to you
                      </p>
                      <div className="section-title-spacer"></div>
                      <a
                        href="#"
                        className="rt-btn rt-light pill rt-xl rt-Bshadow-1 text-uppercase"
                      >
                        Sign UP
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div class="spacer-top"></div>
      <section className="brands-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-9 mx-auto text-center">
              <div className="rt-section-title-wrapper">
                <h2 className="rt-section-title">
                  <span>Take a Look at Our</span>
                  Trusted Partners
                </h2>
                <p>
                  We are committed to being the best partner. Emigrar believes in
                  being your trusted partner and earning that trust through
                  confidence and performance in service and support.
                </p>
              </div>
            </div>
          </div>

          <div className="section-title-spacer"></div>

          <div className="row">
            <div className="col-lg-9 mx-auto">
              <ul className="rt-border-brands">
                {[
                  "brands-1.png",
                  "brands-2.png",
                  "brands-3.png",
                  "brands-4.png",
                  "brands-5.png",
                  "brands-3.png",
                  "brands-2.png",
                  "brands-1.png",
                ].map((img, index) => (
                  <li className="single-border-brands" key={index}>
                    <a
                      href="#"
                      className="wow flipInX d-block animated"
                      style={{ visibility: "visible", animationName: "flipInX" }}
                    >
                      <img
                        src={`https://server1.pearl-developer.com/inditour/public/front/assets/images/brands/${img}`}
                        alt="brands"
                        draggable="false"
                      />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
      <div class="spacer-top"></div>
      {/* <Testimonials /> */}
    </>
  )
}

export default About
