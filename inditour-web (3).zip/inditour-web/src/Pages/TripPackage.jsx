import React from 'react'
import PackageItems from '../Components/PackageItem'
const TripPackage = () => {
  return (
    <>
    <div className="rt-breadcump rt-breadcump-height">
      <div
        className="rt-page-bg rtbgprefix-cover"
        style={{
          backgroundImage:
            "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/bredcump.png')",
        }}
      >
      </div>
      {/* /.rt-page-bg */}
      <div className="container">
        <div className="row rt-breadcump-height">
          <div className="col-12">
            <div className="breadcrumbs-content">
              <h3>Trip Package</h3>
              <div className="breadcrumbs">
                <span className="divider">
                  <i class="fa-solid fa-house"></i>
                </span>
                <a href="/" title="Home">
                  Home
                </a>
                <span className="divider">
                  <i class="fa-solid fa-chevron-right"></i>
                </span>
                Trip Package
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="bredcump--search-trip">
        <div className="container">
          <div className="row">
            <div className="col-lg-10 mx-auto">
              <div className="rt-banner-searchbox trip-search">
                <div className="rt-input-group">
                  <div className="single-input col-md-8">
                    <input
                      type="text"
                      className="form-control _ad_input"
                      placeholder="Depart"
                    />
                      <span className="input-iconbadge">
                        <i className="fa-solid fa-location-dot input-iconbadge"></i>
                      </span>
                  </div>
                  <div className="single-input col-md-3 ms-3">
                    <input
                      type="submit"
                      value="Search"
                      className="rt-btn rt-gradient pill text-uppercase d-block rt-Bshadow-2"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
      <div className="spacer-bottom"></div>
      <section className="content-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 mx-auto col-md-7 mb-5 mb-lg-0">
              <div className="rt-sidebar-group">
                <div className="rt-widget widget_rating">
                  <h3 className="rt-widget-title">Star Rating</h3>
                  <ul>
                    <li className="clearfix">
                      <div className="form-check-inline">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="trip_gridCheckrt-1xs"
                        />
                        <label className="form-check-label" htmlFor="trip_gridCheckrt-1xs">
                          <span>
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                          </span>
                        </label>
                      </div>
                    </li>

                    <li className="clearfix">
                      <div className="form-check-inline">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="trip_gridCheckrt-2xs"
                        />
                        <label className="form-check-label" htmlFor="trip_gridCheckrt-2xs">
                          <span>
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                          </span>
                        </label>
                      </div>
                    </li>

                    <li className="clearfix">
                      <div className="form-check-inline">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="trip_gridCheckrt-2xss"
                        />
                        <label className="form-check-label" htmlFor="trip_gridCheckrt-2xss">
                          <span>
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                          </span>
                        </label>
                      </div>
                    </li>

                    <li className="clearfix">
                      <div className="form-check-inline">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="trip_gridCheckrt-2xssa"
                        />
                        <label className="form-check-label" htmlFor="trip_gridCheckrt-2xssa">
                          <span>
                            <i className="fa-solid fa-star review" />
                            <i className="fa-solid fa-star review" />
                          </span>
                        </label>
                      </div>
                    </li>
                  </ul>
                </div>

                <div className="rt-widget widget_range-slider">
                  <h3 className="rt-widget-title">Filter by Price</h3>
                  <div className="slider-range ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
                    <div
                      className="ui-slider-range ui-widget-header"
                      style={{ left: "21.4286%", width: "45.3571%" }}
                    />
                    <a
                      className="ui-slider-handle ui-state-default ui-corner-all"
                      href="#"
                      style={{ left: "21.4286%" }}
                    />
                    <a
                      className="ui-slider-handle ui-state-default ui-corner-all"
                      href="#"
                      style={{ left: "66.7857%" }}
                    />
                  </div>
                  <div className="price_slider_amount">
                    <div className="clearfix">
                      <div className="float-left">
                        <span>Price:</span>
                      </div>
                      <div className="float-right">
                        <input type="text" className="amount" name="price" placeholder="Add Your Price" />
                      </div>
                    </div>
                  </div>
                  <div className="text-center">
                    <input type="submit" value="Filter" className="rt-btn rt-gradient rounded-sm rt-sm text-uppercase" />
                  </div>
                </div>
                <div className="rt-widget widget_plane_time">
                  <h3 className="rt-widget-title">Payment options</h3>
                  <ul>
                    <li className="clearfix">
                      <div className="form-check form-check-inline">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="trip_gridCheckrt-1"
                        />
                        <label className="form-check-label" htmlFor="trip_gridCheckrt-1">
                          Pay now (72)
                        </label>
                      </div>
                      <span className="float-right">$30</span>
                    </li>
                    <li className="clearfix">
                      <div className="form-check form-check-inline">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="trip_gridCheckrt-2"
                        />
                        <label className="form-check-label" htmlFor="trip_gridCheckrt-2">
                          Pay later (425)
                        </label>
                      </div>
                      <span className="float-right">$32</span>
                    </li>
                  </ul>
                </div>
                <div className="rt-widget widget_tag">
                  <h3 className="rt-widget-title">Activities Transport</h3>
                  <a href="#" className="rt-tag-cloud d-block text-333">
                    <span className="rt-mr-4">
                      <i className="fa-solid fa-tag"></i>
                    </span>
                    Cycling
                  </a>
                  <a href="#" className="rt-tag-cloud d-block text-333">
                    <span className="rt-mr-4">
                      <i className="fa-solid fa-tag"></i>
                    </span>
                    City Tour
                  </a>
                  <a href="#" className="rt-tag-cloud d-block text-333">
                    <span className="rt-mr-4">
                      <i className="fa-solid fa-tag"></i>
                    </span>
                    Meet the Locals
                  </a>
                  <a href="#" className="rt-tag-cloud d-block text-333">
                    <span className="rt-mr-4">
                      <i className="fa-solid fa-tag"></i>
                    </span>
                    Train
                  </a>
                  <a href="#" className="rt-tag-cloud d-block text-333">
                    <span className="rt-mr-4">
                      <i className="fa-solid fa-tag"></i>
                    </span>
                    Car with driver
                  </a>
                </div>
                <div className="rt-widget widget_">
                  <h3 className="rt-widget-title">Main travel focus</h3>
                  <a href="#" className="rt-tag-cloud d-block text-333">
                    <span className="rt-mr-4 primary-color">
                      <i className="fa-solid fa-check"></i>
                    </span>
                    Cultural visits
                  </a>
                  <a href="#" className="rt-tag-cloud d-block text-333">
                    <span className="rt-mr-4 primary-color">
                      <i className="fa-solid fa-check"></i>
                    </span>
                    Nature &amp; landscapes
                  </a>
                  <a href="#" className="rt-tag-cloud d-block text-333">
                    <span className="rt-mr-4 primary-color">
                      <i className="fa-solid fa-check"></i>
                    </span>
                    Relaxing moments
                  </a>
                </div>
              </div>
            </div>

            <div className="col-lg-9">
              <div className="box-style__1 rt-mb-30">
                <form action="#" className="row" data-select2-id="9">
                  <div className="col-lg-3 col-md-6 mb-3 mb-lg-0">
                    <button className="rt-btn pill rt-sm rt-gradient d-block">Recommended</button>
                  </div>
                  <div className="col-lg-3 col-md-6 mb-3 mb-lg-0" data-select2-id="8">
                    <div className="single-input col-rt-in-3 custom_input_filed">
                      <select
                        className="rt-selectactive banner-select"
                        name="from"
                        style={{ width: "100%" }}
                      >
                        <option>Price</option>
                        <option>100</option>
                        <option>200</option>
                        <option>300</option>
                        <option>400</option>
                        <option>500</option>
                        <option>600</option>
                        <option>700</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-lg-3 col-md-6 mb-3 mb-lg-0" data-select2-id="17">
                    <div className="single-input col-rt-in-3 custom_input_filed">
                      <select
                        className="rt-selectactive banner-select"
                        name="from"
                        style={{ width: "100%" }}
                      >
                        <option>Stars</option>
                        <option>100</option>
                        <option>200</option>
                        <option>300</option>
                        <option>400</option>
                        <option>500</option>
                        <option>600</option>
                        <option>700</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-lg-3 rt-input-group mini col-md-6 ">
                    <input type="text" className="form-control" placeholder="Keywords (optional)" />
                  </div>
                </form>
              </div>

              <PackageItems />

              <nav aria-label="Page navigation example">
                <ul className="pagination  rt-paganation justify-content-center">
                  <li className="page-item"><a className="page-link" href="#"><i className="fa-solid fa-angles-right"></i></a></li>
                  <li className="page-item active"><a className="page-link" href="#">01</a></li>
                  <li className="page-item"><a className="page-link" href="#">02</a></li>
                  <li className="page-item"><a className="page-link" href="#">03</a></li>
                  <li className="page-item"><a className="page-link" href="#"><i className="fa-solid fa-angles-left"></i></a></li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default TripPackage
