import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import React, { useState , useEffect } from "react";
import CountUp from "react-countup";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Autoplay, Navigation } from "swiper/modules";
import Testimonials from "../Components/Testimonials";
import { Link } from "react-router-dom";
import BookingComponent from "../Components/BlookingCalender";
import DayTourSlider from "../Components/DayTourSlider";
import PriceRangeTourSlider from "../Components/PriceRangeTourSlider";

const filters = [
  "New York",
  "London",
  "Paris",
  "Hong Kong",
  "Bangkok",
  "Singapore",
  "Tokyo",
];

const portfolioItems = [
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-1.jpg",
    title: "The Millenium Hilton New York",
    price: 239,
    rating: 5,
    reviews: 473,
    categories: ["New York", "London", "Singapore", "Bangkok"],
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-2.jpg",
    title: "The Millenium Hilton London",
    price: 239,
    rating: 5,
    reviews: 473,
    categories: ["Paris", "Hong Kong", "Singapore"],
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-3.jpg",
    title: "The Millenium Hilton Paris",
    price: 239,
    rating: 5,
    reviews: 473,
    categories: ["New York", "Bangkok"],
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-4.jpg",
    title: "The Millenium Hilton Hong Kong",
    price: 239,
    rating: 5,
    reviews: 473,
    categories: ["Bangkok", "Hong Kong", "Singapore"],
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-5.jpg",
    title: "The Millenium Hilton Bangkok",
    price: 239,
    rating: 5,
    reviews: 473,
    categories: ["New York", "Singapore"],
  },
  {
    img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/portfolio/port-6.jpg",
    title: "The Millenium Hilton Singapore",
    price: 239,
    rating: 5,
    reviews: 473,
    categories: ["Hong Kong", "Singapore"],
  },
];

const travelData = {
  international: {
    "1-3": [
      {
        id: 1,
        name: "Bali",
        price: "₹5,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 2,
        name: "Thailand",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 3,
        name: "Singapore",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "4-6": [
      {
        id: 4,
        name: "Dubai",
        price: "₹15,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 5,
        name: "Maldives",
        price: "₹25,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 6,
        name: "Japan",
        price: "₹35,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "7-9": [
      {
        id: 17,
        name: "Goa",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 18,
        name: "Kerala",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 19,
        name: "Uttarakhand",
        price: "₹9,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "13-15": [
      {
        id: 17,
        name: "Goa",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 18,
        name: "Kerala",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 19,
        name: "Uttarakhand",
        price: "₹9,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "15+": [
      {
        id: 17,
        name: "Goa",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 18,
        name: "Kerala",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 19,
        name: "Uttarakhand",
        price: "₹9,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
  },
  domestic: {
    "1-3": [
      {
        id: 14,
        name: "Delhi",
        price: "₹2,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 15,
        name: "Agra",
        price: "₹3,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 16,
        name: "Jaipur",
        price: "₹4,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "4-6": [
      {
        id: 17,
        name: "Goa",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 18,
        name: "Kerala",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 19,
        name: "Uttarakhand",
        price: "₹9,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "7-9": [
      {
        id: 17,
        name: "Goa",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 18,
        name: "Kerala",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 19,
        name: "Uttarakhand",
        price: "₹9,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "13-15": [
      {
        id: 17,
        name: "Goa",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 18,
        name: "Kerala",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 19,
        name: "Uttarakhand",
        price: "₹9,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "7-9": [
      {
        id: 17,
        name: "Goa",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 18,
        name: "Kerala",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 19,
        name: "Uttarakhand",
        price: "₹9,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
    "15+": [
      {
        id: 17,
        name: "Goa",
        price: "₹8,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 18,
        name: "Kerala",
        price: "₹12,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
      {
        id: 19,
        name: "Uttarakhand",
        price: "₹9,999",
        image:
          "	https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      },
    ],
  },
};

const dayRanges = [
  { key: "1-3", label: "1 to 3 days" },
  { key: "4-6", label: "4 to 6 days" },
  { key: "7-9", label: "7 to 9 days" },
  { key: "13-15", label: "13 to 15 days" },
  { key: "15+", label: "15 days or more" },
];



const Home = () => {
  const [activeFilter, setActiveFilter] = useState("New York");
  const [tours, setTours] = useState([]);

  const filteredItems =
    activeFilter === "*"
      ? portfolioItems
      : portfolioItems.filter((item) => item.categories.includes(activeFilter));

  const counters = [
    {
      id: 1,
      img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/counter-icons/counter_iocn_1.png",
      title: "Trusted Members",
      value: 90000,
      suffix: "+",
    },
    {
      id: 2,
      img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/counter-icons/counter_iocn_2.png",
      title: "Our Destinations",
      value: 200,
      suffix: "",
    },
    {
      id: 3,
      img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/counter-icons/counter_iocn_3.png",
      title: "Happy Travelers",
      value: 80000,
      suffix: "+",
    },
  ];

  const works = [
    {
      img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/service-icons/s_icon_4.png",
      title: "Search",
      desc: "Over 1,200,000 Hotels, Apartments and Hostels",
    },
    {
      img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/service-icons/s_icon_5.png",
      title: "Compare & Book",
      desc: "By price, location, rating and more.",
    },
    {
      img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/service-icons/s_icon_6.png",
      title: "Get travel insurance",
      desc: "Buy comprehensive cover for your next trips",
    },
    {
      img: "https://server1.pearl-developer.com/inditour/public/front/assets/images/service-icons/s_icon_7.png",
      title: "Book a room",
      desc: "By finding the best price for your ideal hotel.",
    },
  ];

  const slides = [
    {
      id: 1,
      bgImage:
        "https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      title: "14 Day Classic Tour of Thailand & Beaches",
      shortDesc:
        "Grab a promo code for extra savings up to 75% on discounted hotels!",
      heading: "Take a Look at Our",
      highlight: "Discount Tour",
      desc: "Find great experiences, trips, and activities at fantastic prices around the globe.",
      reviewTitle: "EXCELLENT",
      reviewStars: 5,
      reviewText: "of 205 Reviews",
      reviewedBy: "Kim - Denmark",
      detailTitle: "Thailand Tours and Holidays 2025/2019",
      detailDesc:
        "Thailand is the perfect destination for those who love to spend time outdoors. You can soak up the sunshine on the beautiful beaches of Phuket, or head to Chiang Mai for adventure and outdoor activities.",
    },
    {
      id: 2,
      bgImage:
        "https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/deal-bg.jpg",
      title: "Another Exciting Tour",
      shortDesc: "Book now and save up to 60% on amazing packages!",
      heading: "Discover More",
      highlight: "Amazing Deals",
      desc: "Travel the world with our exclusive tour packages and enjoy unique adventures.",
      reviewTitle: "EXCELLENT",
      reviewStars: 5,
      reviewText: "of 120 Reviews",
      reviewedBy: "Alex - USA",
      detailTitle: "Europe Tours & Holidays 2025",
      detailDesc:
        "Explore the beauty of Europe with guided tours, rich culture, and unforgettable experiences.",
    },
  ];



  const [activeSearchTab, setActiveSearchTab] = useState("flights")

  const tabs = [
    { id: "flights", label: "Flights", icon: "fa-solid fa-plane" },
    { id: "hotels", label: "Hotels", icon: "fa-solid fa-hotel" },
    { id: "cars", label: "Cars", icon: "fa-solid fa-car" },
    { id: "trains", label: "Trains", icon: "fa-solid fa-train" },
  ]

  // Tour Slider Api------------
  
  useEffect(() => {
    fetch("https://api.inditour.com/api/v1/tours")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setTours(data.data);
        }
      })
      .catch((err) => console.error("Error fetching tours:", err));
  }, []);



  return (
    <>
      <section className="rt-banner-area">
        <div
          className="single-rt-banner rt-banner-height"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/all-img/banner01.png')",
          }}
        >
          <div className="container">
            <div className="row rt-banner-height align-items-center">
              <div className="col-lg-9">
                <div className="rt-banner-content">
                  <h1
                    className="wow fade-in-bottom animated"
                    data-wow-duration="1s"
                    data-wow-delay="0.5s"
                  >
                    Explore <br /> The World!
                  </h1>
                  <p className="wow fade-in-top animated">
                    You can create a Custom Trip. Search Our Lowest Fares to{" "}
                    <br />
                    Your Favorite Destinations. Find a better way to travel
                  </p>
                  {/* Search box */}
      <div className="rt-banner-searchbox standard-search">
        <div className="tab-content">
          {activeSearchTab === "flights" && (
            <div className="tab-pane show active">
              <form>
                <div className="rt-radio-group">
                  <div className="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="oneway" name="trip" className="custom-control-input" />
                    <label className="custom-control-label" htmlFor="oneway">One-way</label>
                  </div>
                  <div className="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="roundtrip" name="trip" className="custom-control-input" />
                    <label className="custom-control-label" htmlFor="roundtrip">Round-trip</label>
                  </div>
                  <div className="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="multicity" name="trip" className="custom-control-input" />
                    <label className="custom-control-label" htmlFor="multicity">Multi-city</label>
                  </div>
                </div>

                <div className="rt-input-group">
                  <div className="single-input col-rt-in-3">
                    <i class="fa-solid fa-plane-departure"></i>
                    <input type="text" className="form-control" placeholder="From" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-solid fa-plane-arrival"></i>
                    <input type="text" className="form-control" placeholder="To" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-regular fa-calendar-days"></i>
                    <input type="text" className="form-control" placeholder="Depart" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-regular fa-calendar-days"></i>
                    <input type="text" className="form-control" placeholder="Return" />
                  </div>
                  <div className="single-input col-rt-in-1">
                    <button type="submit"><i class="fa-solid fa-magnifying-glass position-static"></i></button>
                  </div>
                </div>
              </form>
            </div>
          )}

          {activeSearchTab === "hotels" && (
            <div className="tab-pane show active">
              <form>
                <div className="rt-input-group">
                  <div className="single-input col-rt-in-3">
                    <i class="fa-solid fa-hotel"></i>
                    <input type="text" className="form-control" placeholder="Destination" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-regular fa-calendar-days"></i>
                    <input type="text" className="form-control" placeholder="Check-in" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-regular fa-calendar-days"></i>
                    <input type="text" className="form-control" placeholder="Check-out" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <input type="text" className="form-control" placeholder="Guests" />
                  </div>
                  <div className="single-input col-rt-in-1">
                    <button type="submit"><i class="fa-solid fa-magnifying-glass position-static"></i></button>
                  </div>
                </div>
              </form>
            </div>
          )}

          {activeSearchTab === "cars" && (
            <div className="tab-pane show active">
              <form>
                <div className="rt-input-group">
                  <div className="single-input col-rt-in-3">
                    <i class="fa-solid fa-car"></i>
                    <input type="text" className="form-control" placeholder="Pick-up location" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-solid fa-car"></i>
                    <input type="text" className="form-control" placeholder="Drop-off location" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-regular fa-calendar-days"></i>
                    <input type="text" className="form-control" placeholder="Pick-up date" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-regular fa-calendar-days"></i>
                    <input type="text" className="form-control" placeholder="Return date" />
                  </div>
                  <div className="single-input col-rt-in-1">
                    <button type="submit"><i class="fa-solid fa-magnifying-glass position-static"></i></button>
                  </div>
                </div>
              </form>
            </div>
          )}

          {activeSearchTab === "trains" && (
            <div className="tab-pane show active">
              <form>
                <div className="rt-input-group">
                  <div className="single-input col-rt-in-3">
                    <i class="fa-solid fa-train"></i>
                    <input type="text" className="form-control" placeholder="From" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-regular fa-calendar-days"></i>
                    <input type="text" className="form-control" placeholder="To" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <i class="fa-regular fa-calendar-days"></i>
                    <input type="text" className="form-control" placeholder="Date" />
                  </div>
                  <div className="single-input col-rt-in-3">
                    <input type="text" className="form-control" placeholder="Train No.(Optional)" style={{paddingLeft:".75rem"}} />
                  </div>
                  <div className="single-input col-rt-in-1">
                    <button type="submit"><i class="fa-solid fa-magnifying-glass position-static"></i></button>
                  </div>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>

      {/* Tabs Navigation */}
      <ul className="nav serachnavs" role="tablist">
        {tabs.map((tab) => (
          <li key={tab.id} className="nav-item">
            <button
              className={`nav-link ${activeSearchTab === tab.id ? "active" : "inactive"}`}
              onClick={() => setActiveSearchTab(tab.id)}
            >
              <i className={tab.icon}></i>
              <span>{tab.label}</span>
            </button>
          </li>
        ))}
      </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="counter-area">
        <div className="container">
          <div className="row">
            {counters.map((item) => (
              <div key={item.id} className="col-lg-4 col-md-6 col-12">
                <div className="media counter-box-1 align-items-center wow fadeInUp">
                  <img src={item.img} alt={item.title} draggable="false" />
                  <div className="media-body">
                    <h5>{item.title}</h5>
                    <h6>
                      <CountUp
                        start={0}
                        end={item.value}
                        duration={2.5}
                        separator=","
                      />
                      <span>{item.suffix}</span>
                    </h6>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <section
        className="_ad_slide emigr-services-area rtbgprefix-contain travel_agency"
        style={{
          backgroundImage:
            "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/dotbg.png')",
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-8 text-center mx-auto">
              <div className="rt-section-title-wrapper">
                <h2 className="rt-section-title">
                  <span>WHY Choose Our Travel Agency?</span>
                  Our Hot Selling Tours
                </h2>
                <p>
                  Our thoughtful team of knowledgeable experts are here to take
                  care of every need, from the second you contact us to when you
                  return
                </p>
              </div>
            </div>
          </div>

          <div className="section-title-spacer"></div>

          <div style={{ position: "relative", width: "100%" }}>
            <Swiper
              slidesPerView={3}
              spaceBetween={30}
              loop={true}
              autoplay={{
                delay: 2500,
                disableOnInteraction: false,
              }}
              navigation={true}
              breakpoints={{
                150: { slidesPerView: 1 },
                350: { slidesPerView: 1 },
                768: { slidesPerView: 2 },
                1200: { slidesPerView: 3 },
                1400: { slidesPerView: 3 },
              }}
              modules={[Navigation, Autoplay]}
              className="mySwiper agency_swiper"
            >
              {tours.map((tour) => (
                <SwiperSlide key={tour.id}>
                  <Link to={`/trip-detail/${tour.id}`} className="text-dark">
                  <div className="services-box-1 text-center">
                    <div className="services-thumb">
                      <img
                        src={tour.tour_images && tour.tour_images.length > 0 ? tour.tour_images[0].secure_url : "/placeholder.svg"}
                        alt={tour.tour_name}
                        draggable="false"
                      />
                    </div>
                    <h4>{tour.tour_name}</h4>
                    <p>{tour.tour_caption}</p>
                  </div>
                  </Link>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </div>
      </section>

      <section
        className="_ad_slide emigr-services-area rtbgprefix-contain travel_agency"
        style={{
          backgroundImage:
            "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/dotbg.png')",
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-8 text-center mx-auto">
              <div className="rt-section-title-wrapper">
                <h2 className="rt-section-title">
                  <span>WHY Choose Our Short Tours?</span>
                  Our Best-Selling Quick Escapes
                </h2>
                <p>
                  From weekend getaways to quick adventures, we make sure every
                  trip is stress-free, affordable, and full of unforgettable
                  memories.
                </p>
              </div>
            </div>
          </div>

          <div className="section-title-spacer"></div>

          <Swiper
            slidesPerView={3}
            spaceBetween={30}
            loop={true}
            autoplay={{
              delay: 2500,
              disableOnInteraction: false,
            }}
            navigation={true}
            breakpoints={{
               150: { slidesPerView: 1 }, 
              350: { slidesPerView: 1 }, 
              768: { slidesPerView: 2 }, 
              1200: { slidesPerView: 3 },  
              1400: { slidesPerView: 3 }, 
            }}
            modules={[Navigation, Autoplay]}
            className="mySwiper short_tour_swiper"
          >
            {tours.map((tour) => (
              <SwiperSlide key={tour.id}>
                <Link to={`/trip-detail/${tour.id}`} className="text-dark">
                  <div className="services-box-1 text-center">
                    <div className="services-thumb">
                      <img
                        src={tour.tour_images && tour.tour_images.length > 0 ? tour.tour_images[0].secure_url : "/placeholder.svg"}
                        alt={tour.tour_name}
                        draggable="false"
                      />
                    </div>
                    <h4>{tour.tour_name}</h4>
                    <p>{tour.tour_caption}</p>
                    <div className="d-flex align-items-center justify-content-between mt-2 w-100">
                      <p className="tour_time">{tour.tour_duration_type}</p>
                      <p>From <strong>{tour.original_price}</strong> / Per Person</p>
                    </div>
                  </div>
                </Link>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </section>

      <DayTourSlider />

      <section
        className="deal-area rtbgprefix-full bg-hide-md _ad_bg_discount"
        style={{
          backgroundImage:
            "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/bgshapes_1.png')",
        }}
      >
        <div className="container-fluid p-0">
          <Swiper
            modules={[Navigation, Autoplay]}
            navigation
            autoplay={{ delay: 4000 }}
            loop={true}
            slidesPerView={1}
            className="deal-carosel-active deal_carousel_sec"
          >
            {slides.map((slide) => (
              <SwiperSlide key={slide.id}>
                <div className="row single-deal-carosel align-items-center">
                  {/* Left Side - Background + Title */}
                  <div className="col-lg-5">
                    <div
                      className="deal-bg"
                      style={{ backgroundImage: `url(${slide.bgImage})` }}
                    >
                      <div className="inner-content">
                        <h4>{slide.title}</h4>
                        <p>{slide.shortDesc}</p>
                      </div>
                    </div>
                  </div>

                  {/* Right Side - Details */}
                  <div className="col-lg-7">
                    <div className="rt-section-title-wrapper text-white _ad_discount_content">
                      <h2 className="rt-section-title text-white">
                        <span className="text-white">{slide.heading}</span>{" "}
                        {slide.highlight}
                      </h2>
                      <p className="text-white">{slide.desc}</p>
                      <div className="section-title-spacer"></div>

                      <div className="deal-bottom-content">
                        {/* Rating Box */}
                        <div className="rating-box">
                          <span className="d-block">{slide.reviewTitle}</span>
                          <span className="d-block">
                            {[...Array(slide.reviewStars)].map((_, i) => (
                              <i key={i} className="fas fa-star"></i>
                            ))}{" "}
                            {slide.reviewText}
                          </span>
                          <span className="d-block">
                            Reviewed by {slide.reviewedBy}
                          </span>
                        </div>

                        <div className="section-title-spacer"></div>
                        <h4>{slide.detailTitle}</h4>
                        <p className="text-white">{slide.detailDesc}</p>

                        <div className="rt-button-group">
                          <a
                            href="#"
                            className="rt-btn rt-gradient rt-rounded rt-Bshadow-2"
                          >
                            Read More
                          </a>
                          <a
                            href="#"
                            className="rt-btn rt-outline-gradientL rt-rounded"
                          >
                            Help Me Plan My Trip
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </section>

      <PriceRangeTourSlider />

      <div className="spacer-top"></div>

      <section className="works-area">
        <div className="container">
          <div className="row">
            <div className="col-xl-10 text-center mx-auto">
              <div className="rt-section-title-wrapper">
                <h2 className="rt-section-title">
                  <span>Here's How It Works</span>
                  Getting Started? It’s Simple
                </h2>
                <p>
                  Prepare For Your Trip. Find out all you need to know before
                  you go. Traveling is as unique as you are. And there is no one
                  package that fits all. That's why we offer customized travel
                  packages.
                </p>
              </div>
            </div>
          </div>

          <div className="section-title-spacer"></div>

          <div className="row">
            {works.map((item, index) => (
              <div
                key={index}
                className="col-lg-3 col-md-6 col-6 mx-auto text-center"
              >
                <div className="services-box-2 wow fade-in-bottom animated">
                  <div className="services-thumb">
                    <img src={item.img} alt={item.title} draggable="false" />
                  </div>
                  <div className="content_sec position-relative">
                    <span className="inner-counter">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <h4>{item.title}</h4>
                    <p>{item.desc}</p>
                  </div>
                </div>
              </div>
            ))}

            <div className="col-12 text-center mt-4">
              <a
                href="#"
                className="rt-btn rt-gradient text-uppercase rt-sm rt-rounded rt-Bshadow-2"
              >
                Tour the world
              </a>
            </div>
          </div>
        </div>
      </section>
      <div className="spacer-top"></div>

      <section
        className="portfolio-area rt-section-padding rtbgprefix-full bg-hide-md gradinet-bg-md _ad_hot_selling"
        style={{
          backgroundImage:
            "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/portfoliobg.png')",
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-xl-8 text-center mx-auto text-center">
              <div className="rt-section-title-wrapper text-white">
                <h2 className="rt-section-title">
                  <span className="text-white">Take a Look at Our</span>
                  Hot selling Country
                </h2>
                <p className="text-white">
                  We've made a list of suggested activities based on your
                  interests. Browse through our most popular Hotels! Our
                  Featured Tours can help you find the trip that's perfect for
                  you!.
                </p>
              </div>
            </div>
          </div>

          <div className="section-title-spacer"></div>

          <div className="row">
            <div className="col-12">
              <ul className="filter-list">
                {filters.map((filter, index) => (
                  <li
                    key={index}
                    className={activeFilter === filter ? "active" : ""}
                    onClick={() => setActiveFilter(filter)}
                    style={{ cursor: "pointer" }}
                  >
                    {filter}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="row grid">
            {filteredItems.map((item, index) => (
              <div key={index} className="col-lg-4 col-md-6 grid-item">
                <div
                  className="portfolio-box-1 wow fade-in-bottom animated"
                  style={{ backgroundImage: `url(${item.img})` }}
                >
                  <div className="rt-overlay"></div>
                  <div className="portfolio-badge">
                    <span>From</span>
                    <span>
                      <sup>$</sup>
                      {item.price}
                    </span>
                  </div>
                  <div className="inner-content text-white">
                    <h6>{item.title}</h6>
                    <p>
                      <span>
                        {Array.from({ length: item.rating }).map((_, i) => (
                          <i key={i} className="fas fa-star"></i>
                        ))}
                      </span>
                      <span>
                        {item.rating}.5 / 5 ({item.reviews} reviews)
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="row">
            <div className="col-12 text-center mt-4">
              <a
                href="#"
                className="rt-btn rt-gradient text-uppercase rt-sm rt-rounded rt-Bshadow-1"
              >
                browse more
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="testimonial_section">
        <div className="container">
          <div className="row">
            <div className="col-xl-8 text-center mx-auto text-center mb-5">
              <div className="rt-section-title-wrapper text-white">
                <h2 className="rt-section-title" style={{ color: " #212529" }}>
                  <span className="">testimonials</span>
                  What Our Customers Say
                </h2>
                <p className="">
                  We have many happy customers that have booked holidays with
                  us.Some Impresions from our Customers! Please read some of the
                  lovely things our Customers say about us.
                </p>
              </div>
            </div>
          </div>
          <Testimonials />
        </div>
      </section>

      <section>
        <BookingComponent />
      </section>

      <div class="spacer-top"></div>
      <section className="brands-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-9 mx-auto text-center">
              <div className="rt-section-title-wrapper">
                <h2 className="rt-section-title">
                  <span>Take a Look at Our</span>
                  Trusted Partners
                </h2>
                <p>
                  We are committed to being the best partner. Emigrar believes
                  in being your trusted partner and earning that trust through
                  confidence and performance in service and support.
                </p>
              </div>
            </div>
          </div>

          <div className="section-title-spacer"></div>

          <div className="row">
            <div className="col-lg-9 mx-auto">
              <ul className="rt-border-brands">
                {[
                  "brands-1.png",
                  "brands-2.png",
                  "brands-3.png",
                  "brands-4.png",
                  "brands-5.png",
                  "brands-3.png",
                  "brands-2.png",
                  "brands-1.png",
                ].map((img, index) => (
                  <li className="single-border-brands" key={index}>
                    <a
                      href="#"
                      className="wow flipInX d-block animated"
                      style={{
                        visibility: "visible",
                        animationName: "flipInX",
                      }}
                    >
                      <img
                        src={`https://server1.pearl-developer.com/inditour/public/front/assets/images/brands/${img}`}
                        alt="brands"
                        draggable="false"
                      />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
