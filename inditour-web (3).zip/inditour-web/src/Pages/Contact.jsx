import React from 'react'

const Contact = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted!");
  };
  return (
    <>
      <div className="rt-breadcump rt-breadcump-height">
        <div
          className="rt-page-bg rtbgprefix-cover"
          style={{
            backgroundImage:
              "url('https://server1.pearl-developer.com/inditour/public/front/assets/images/backgrounds/bredcump.png')",
          }}
        ></div>
        <div className="container">
          <div className="row rt-breadcump-height">
            <div className="col-12">
              <div className="breadcrumbs-content">
                <h3>Contact Us</h3>
                <div className="breadcrumbs">
                  <span className="divider">
                    <i class="fa-solid fa-house"></i>
                  </span>
                  <a href="/" title="Home">
                    Home
                  </a>
                  <span className="divider">
                    <i class="fa-solid fa-chevron-right"></i>
                  </span>
                  Contact Us
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <section className="contact-area">
      {/* <div
        className="rt-design-elmnts rtbgprefix-contain"
        style={{ backgroundImage: `url(${bgImage})` }}
      ></div> */}

      <div className="container">
        <div className="row">
          <div className="col-lg-7">
            <div className="rt-section-title-wrapper">
              <h2 className="rt-section-title">
                <span>Contact us</span>
                Get In Touch
              </h2>
              <p>
                Any kind of travel information don't hesitate to contact with us
                for immediate customer support. We love to hear from you.
              </p>
              <div className="section-title-spacer"></div>

              {/* Contact Form */}
              <form onSubmit={handleSubmit} className="rt-form rt-line-form">
                <input
                  type="text"
                  placeholder="Name"
                  className="form-control rt-mb-30"
                  required
                />
                <input
                  type="email"
                  placeholder="Email"
                  className="form-control rt-mb-30"
                  required
                />
                <textarea
                  placeholder="Message"
                  className="form-control rt-mb-30"
                  style={{ height: "154px" }}
                  required
                ></textarea>
                <input
                  type="submit"
                  value="SUBMIT NOW"
                  className="rt-btn rt-gradient pill text-uppercase rt-mb-30"
                />
              </form>
            </div>
          </div>
        </div>
        <div className="section-title-spacer"></div>
      </div>
      </section>

      <section className="rt-map-area">
      <div className="container">
        <div className="row">
          {/* Address */}
          <div className="col-lg-4 mx-auto col-md-6">
            <div className="rt-single-icon-box icon-center text-center justify-content-center shdoaw-style wow fadeInUp animated">
              <div className="icon-thumb">
                <img
                  src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/con-1.png"
                  alt="box-icon"
                  draggable="false"
                />
              </div>
              <div className="iconbox-content">
                <h5>Our Address</h5>
                <p>
                  971-949 8th Ave <br />
                  New York, NY
                </p>
              </div>
            </div>
          </div>

          {/* Phone & Email */}
          <div className="col-lg-4 mx-auto col-md-6">
            <div
              className="rt-single-icon-box icon-center text-center justify-content-center shdoaw-style wow fadeInUp animated"
              data-wow-duration="1.5s"
            >
              <div className="icon-thumb">
                <img
                  src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/con-2.png"
                  alt="box-icon"
                  draggable="false"
                />
              </div>
              <div className="iconbox-content">
                <h5>Phone &amp; Email</h5>
                <p>
                  (123) 456 7890 <br />
                  contact@example.com
                </p>
              </div>
            </div>
          </div>

          {/* Stay in Touch */}
          <div className="col-lg-4 mx-auto col-md-6">
            <div
              className="rt-single-icon-box icon-center text-center justify-content-center shdoaw-style wow fadeInUp animated"
              data-wow-duration="2s"
            >
              <div className="icon-thumb">
                <img
                  src="https://server1.pearl-developer.com/inditour/public/front/assets/images/icons-image/con-3.png"
                  alt="box-icon"
                  draggable="false"
                />
              </div>
              <div className="iconbox-content">
                <h5>Stay In Touch</h5>
                <ul className="rt-social rt-circle-style">
                  <li>
                    <a href="#">
                      <i class="fa-brands fa-facebook"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa-brands fa-twitter"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa-brands fa-linkedin"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Google Map */}
      <div className="googleMap">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d116834.1509316622!2d90.34928591742289!3d23.780620653401414!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b087026b81%3A0x8fa563bbdd5904c2!2sDhaka!5e0!3m2!1sen!2sbd!4v1569663745803!5m2!1sen!2sbd"
          width="100%"
          height="582"
          style={{ border: "0" }}
          allowFullScreen
          loading="lazy"
          title="Google Map"
        ></iframe>
      </div>
    </section>
    
      <section className="brands-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-9 mx-auto text-center">
              <div className="rt-section-title-wrapper">
                <h2 className="rt-section-title">
                  <span>Take a Look at Our</span>
                  Trusted Partners
                </h2>
                <p>
                  We are committed to being the best partner. Emigrar believes in
                  being your trusted partner and earning that trust through
                  confidence and performance in service and support.
                </p>
              </div>
            </div>
          </div>

          <div className="section-title-spacer"></div>

          <div className="row">
            <div className="col-lg-9 mx-auto">
              <ul className="rt-border-brands">
                {[
                  "brands-1.png",
                  "brands-2.png",
                  "brands-3.png",
                  "brands-4.png",
                  "brands-5.png",
                  "brands-3.png",
                  "brands-2.png",
                  "brands-1.png",
                ].map((img, index) => (
                  <li className="single-border-brands" key={index}>
                    <a
                      href="#"
                      className="wow flipInX d-block animated"
                      style={{ visibility: "visible", animationName: "flipInX" }}
                    >
                      <img
                        src={`https://server1.pearl-developer.com/inditour/public/front/assets/images/brands/${img}`}
                        alt="brands"
                        draggable="false"
                      />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Contact
