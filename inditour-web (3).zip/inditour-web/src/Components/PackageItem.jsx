import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const PackageItems = () => {
  const [tours, setTours] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("https://api.inditour.com/api/v1/tours")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setTours(data.data);
        } else {
          setError("No tours found");
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching tours:", err);
        setError("Something went wrong while fetching tours");
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading tours...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="row">
      {tours.map((tour) => (
        <div key={tour.id} className="box-style__1 rt-mb-30 col-12">
          <div className="hotel-inner-content row">
            {/* Thumbnail */}
            <div className="hotel-thumb col-md-3 mb-5 mb-md-0">
              <div
                className="hotel-bg rtbgprefix-cover"
                style={{
                  backgroundImage: `url('${
                    tour.tour_images?.[0]?.secure_url ||
                    "https://via.placeholder.com/300x200"
                  }')`,
                }}
              />
            </div>

            {/* Text Section */}
            <div className="hotel-text col-md-9">
              <div className="top">
                <h5>
                  {tour.tour_name}{" "}
                  <span>
                    <i className="fa-solid fa-star review" />
                    <i className="fa-solid fa-star review" />
                    <i className="fa-solid fa-star review" />
                    <i className="fa-solid fa-star review" />
                    <i className="icofont-star" />
                  </span>
                </h5>
                <p>
                  {tour.tour_caption}{" "}
                  <span> - {tour.destination?.destination_name}</span>
                </p>
              </div>

              {/* Middle Info */}
              <div className="middle-text d-md-flex justify-content-md-between rt-mt-20">
                <div className="left_column">
                  <span className="badge rt-gradinet-badge pill rt-mr-10">
                    4.3 <small>/5</small>
                  </span>
                  <span className="primary-color">Excellent</span>
                  <span className="f-size-12 text-878">( 86 Reviews )</span>
                  <span className="text-555 f-size-16 d-block rt-mt-15">
                    <span>
                      <i className="icofont-user primary-color rt-mr-4" />
                      {tour.tour_highlights}
                    </span>
                  </span>
                </div>
                <div className="right_column text-left text-md-right">
                  <span className="d-block text-primary f-size-24 rt-semiblod title-font">
                    ₹{tour.discounted_price}
                  </span>
                  <span className="d-block f-size-12 text-878">Per Person</span>
                </div>
              </div>

              {/* Footer */}
              <div className="footer-elements d-flex justify-content-between align-items-center align-items-end">
                <div className="left">
                  <a href="#">Customize &amp; Request</a>
                </div>
                <div className="right">
                  <Link
                    to={`/trip-detail/${tour.id}`}
                    className="rt-btn rt-gradient pill rt-sm3 text-uppercase"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default PackageItems;
