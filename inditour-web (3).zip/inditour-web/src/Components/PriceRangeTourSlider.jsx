import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import { Link } from "react-router-dom";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

const priceRanges = [
  { key: "1k-10k", label: "Less than Rs. 10,000", min: 0, max: 10000 },
  { key: "10k-20k", label: "Rs. 10,000 to Rs. 20,000", min: 10000, max: 20000 },
  { key: "20k-40k", label: "Rs. 20,000 to Rs. 40,000", min: 20000, max: 40000 },
  { key: "40k-60k", label: "Rs. 40,000 to Rs. 60,000", min: 40000, max: 60000 },
  { key: "60k-80k", label: "Rs. 60,000 to Rs. 80,000", min: 60000, max: 80000 },
  { key: "80k+", label: "Above Rs. 80,000", min: 80000, max: Infinity },
];

const PriceRangeTourSlider = () => {
  const [tours, setTours] = useState([]);
  const [activePriceRange, setActivePriceRange] = useState("1k-10k");

  // Fetch Tours from API
  useEffect(() => {
    fetch("https://api.inditour.com/api/v1/tours")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setTours(data.data);
        }
      })
      .catch((err) => console.error("Error fetching tours:", err));
  }, []);

  const currentRange = priceRanges.find((r) => r.key === activePriceRange);

  const filteredTours = tours.filter((tour) => {
    const price = tour.discounted_price || tour.original_price;
    return price >= currentRange.min && price <= currentRange.max;
  });

  return (
    <section className="day_tours">
      <div className="travel-container">
        <div className="travel-header">
          <h1>Choose Your Destination by Budget</h1>
          <p className="text-center">Filter by Budget Ranges</p>

          <div className="filters">
            {priceRanges.map((range) => (
              <button
                key={range.key}
                className={`filter-btn ${
                  activePriceRange === range.key ? "active" : ""
                }`}
                onClick={() => setActivePriceRange(range.key)}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>

        <div className="slider-wrap position-relative">
          {filteredTours.length > 0 ? (
            <Swiper
              modules={[Navigation, Pagination]}
              spaceBetween={20}
              slidesPerView={1}
              navigation={{
                nextEl: ".swiper-button-next-custom",
                prevEl: ".swiper-button-prev-custom",
              }}
              pagination={{
                clickable: true,
                el: ".swiper-pagination-custom",
                bulletClass: "custom-bullet",
                bulletActiveClass: "custom-bullet-active",
              }}
              breakpoints={{
                576: { slidesPerView: 2 },
                768: { slidesPerView: 3 },
                1024: { slidesPerView: 4 },
                1280: { slidesPerView: 4 },
              }}
            >
              {filteredTours.map((tour) => (
                <SwiperSlide key={tour.id}>
                  <Link to={`/trip-detail/${tour.id}`} className="text-dark">
                    <div className="card">
                      <div className="card-img">
                        <img
                          src={
                            tour.tour_images && tour.tour_images.length > 0
                              ? tour.tour_images[0].secure_url
                              : "/placeholder.svg"
                          }
                          alt={tour.tour_name}
                          draggable="false"
                        />
                        <div className="overlay"></div>
                        <div className="card-title">
                          <h3>{tour.tour_name}</h3>
                          <p className="duration mb-0">
                            {tour.tour_duration[0]} {tour.tour_duration_type}
                          </p>
                        </div>
                      </div>
                      <div className="card-content">
                        <span className="starting">Starting from</span>
                        <span className="price">₹{tour.original_price}</span>
                      </div>
                    </div>
                  </Link>
                </SwiperSlide>
              ))}
            </Swiper>
          ) : (
            <p className="no-tours">No tours available in this price range</p>
          )}

          {/* Navigation Buttons */}
          <button className="swiper-button-prev-custom nav-btn">
            <svg className="icon" viewBox="0 0 24 24">
              <path
                d="M15 19l-7-7 7-7"
                stroke="currentColor"
                strokeWidth="2"
                fill="none"
              />
            </svg>
          </button>
          <button className="swiper-button-next-custom nav-btn">
            <svg className="icon" viewBox="0 0 24 24">
              <path
                d="M9 5l7 7-7 7"
                stroke="currentColor"
                strokeWidth="2"
                fill="none"
              />
            </svg>
          </button>
        </div>

        <div className="pagination-wrap">
          <div className="swiper-pagination-custom"></div>
        </div>
      </div>
    </section>
  );
};

export default PriceRangeTourSlider;
