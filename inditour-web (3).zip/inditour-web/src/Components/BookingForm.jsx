import React, { useState, useEffect } from "react";
import axios from "axios";

const TourEnquiryForm = ({ data, tourId,amount }) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    guest: 1,
    message: "",
    travelDate: "",
  });

  const [userId, setUserId] = useState(null);

  // get logged-in userId from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUserId(parsedUser?.id || parsedUser?.userId); // depends on API response
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      ...formData,
      userId: userId,
      tourId: tourId,
      totalAmount: amount,
    };

    try {
      const res = await axios.post(
        `https://api.inditour.com/api/v1/booking`,
        payload
      );
      alert("Booking submitted successfully!");
      console.log("Booking Response:", res.data);
    } catch (err) {
      console.error("Error submitting booking:", err);
      alert("Something went wrong. Please try again.");
    }
  };

  return (
    <div className="container mt-4">
      <h3>Tour Enquiry Form</h3>
      <form onSubmit={handleSubmit} className="row g-3">

        {/* Name */}
        <div className="col-md-6">
          <label className="form-label">Full Name</label>
          <input
            type="text"
            name="name"
            className="form-control"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        {/* Email */}
        <div className="col-md-6">
          <label className="form-label">Email</label>
          <input
            type="email"
            name="email"
            className="form-control"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>

        {/* Phone */}
        <div className="col-md-6">
          <label className="form-label">Phone</label>
          <input
            type="text"
            name="phone"
            className="form-control"
            value={formData.phone}
            onChange={handleChange}
            required
          />
        </div>

        {/* Guests */}
        <div className="col-md-6">
          <label className="form-label">No. of Guests</label>
          <input
            type="number"
            name="guest"
            className="form-control"
            value={formData.guest}
            onChange={handleChange}
            min="1"
            required
          />
        </div>

        {/* Travel Date */}
        <div className="col-md-6">
          <label className="form-label">Travel Date</label>
          <input
            type="date"
            name="travelDate"
            className="form-control"
            value={formData.travelDate}
            onChange={handleChange}
            required
          />
        </div>

        {/* Message */}
        <div className="col-12">
          <label className="form-label">Message</label>
          <textarea
            name="message"
            className="form-control"
            rows="3"
            value={formData.message}
            onChange={handleChange}
          ></textarea>
        </div>

        {/* Submit */}
        <div className="col-12">
          <button type="submit" className="btn btn-primary">
            Submit Enquiry
          </button>
        </div>
      </form>
    </div>
  );
};

export default TourEnquiryForm;
