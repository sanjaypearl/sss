
import { useState } from "react"

const testimonials = [
  {
    id: 1,
    name: "Oliver Wolfe",
    location: "United Kingdom",
    date: "15th December, 2025",
    rating: 5,
    text: "Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we were interested in. The hotels were nice and situated very close to the station. This made travelling in the city very easy. The tours planned were also very good with very nice guides. We would definitely recommend a trip with them.",
    avatar: "https://server1.pearl-developer.com/inditour/public/front/assets/images/testimonials/t_2.png",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    location: "United States",
    date: "8th December, 2025",
    rating: 5,
    text: "Absolutely fantastic service! The team went above and beyond to ensure our vacation was perfect. Every detail was carefully planned and executed flawlessly. The customer support was exceptional throughout our entire journey.",
    avatar: "https://server1.pearl-developer.com/inditour/public/front/assets/images/testimonials/t_3.png",
  },
  {
    id: 3,
    name: "Michael Chen",
    location: "Canada",
    date: "22nd November, 2025",
    rating: 4,
    text: "Great experience overall! The booking process was smooth and the recommendations were spot on. Our family had an amazing time and created memories that will last a lifetime. Highly recommend their services.",
    avatar: "https://server1.pearl-developer.com/inditour/public/front/assets/images/testimonials/t_2.png",
  },
  {
    id: 4,
    name: "Emma Rodriguez",
    location: "Spain",
    date: "30th November, 2025",
    rating: 5,
    text: "Professional, reliable, and incredibly helpful. They understood exactly what we were looking for and delivered beyond our expectations. The attention to detail was remarkable and made our trip stress-free.",
    avatar: "https://server1.pearl-developer.com/inditour/public/front/assets/images/testimonials/t_4.png",
  },
  {
    id: 5,
    name: "David Thompson",
    location: "Australia",
    date: "12th December, 2025",
    rating: 5,
    text: "Outstanding service from start to finish. The team's expertise and dedication really showed in every aspect of our experience. Would definitely use their services again and recommend to friends and family.",
    avatar: "https://server1.pearl-developer.com/inditour/public/front/assets/images/testimonials/t_5.png",
  },
  {
    id: 6,
    name: "Lisa Anderson",
    location: "Germany",
    date: "5th December, 2025",
    rating: 4,
    text: "Very impressed with the quality of service. Everything was well organized and the staff was incredibly friendly and accommodating. Made our special occasion even more memorable.",
    avatar: "	https://server1.pearl-developer.com/inditour/public/front/assets/images/testimonials/t_6.png",
  },
  {
    id: 7,
    name: "James Wilson",
    location: "New Zealand",
    date: "18th November, 2025",
    rating: 5,
    text: "Exceptional experience! The personalized approach and attention to our specific needs made all the difference. Couldn't have asked for better service and support throughout the entire process.",
    avatar: "https://server1.pearl-developer.com/inditour/public/front/assets/images/testimonials/t_7.png",
  },
  {
    id: 8,
    name: "Maria Garcia",
    location: "Mexico",
    date: "25th November, 2025",
    rating: 5,
    text: "Wonderful team to work with! They made everything so easy and enjoyable. The level of professionalism and care they showed was truly impressive. Highly recommend their services to anyone.",
    avatar: "	https://server1.pearl-developer.com/inditour/public/front/assets/images/testimonials/t_8.png",
  },
]

export default function TestimonialSection() {
  const [activeTestimonial, setActiveTestimonial] = useState(testimonials[0])

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <span key={i} className={`star ${i < rating ? "active" : ""}`}>
        ★
      </span>
    ))
  }

  return (
    <section className="testimonial-section">
     

      <div className="layout">
        <div className="profiles">
          <div className="profile top-left">
            <button onClick={() => setActiveTestimonial(testimonials[1])} className="profile-btn large">
              <img src={testimonials[1].avatar} alt={testimonials[1].name} />
            </button>
          </div>

          <div className="profile top-right">
            <button onClick={() => setActiveTestimonial(testimonials[2])} className="profile-btn large">
              <img src={testimonials[2].avatar} alt={testimonials[2].name} />
            </button>
          </div>

          <div className="profile left-center">
            <button onClick={() => setActiveTestimonial(testimonials[3])} className="profile-btn small">
              <img src={testimonials[3].avatar} alt={testimonials[3].name} />
            </button>
          </div>

          <div className="profile left-bottom">
            <button onClick={() => setActiveTestimonial(testimonials[4])} className="profile-btn medium">
              <img src={testimonials[4].avatar} alt={testimonials[4].name} />
            </button>
          </div>

          <div className="profile right-center">
            <button onClick={() => setActiveTestimonial(testimonials[5])} className="profile-btn small">
              <img src={testimonials[5].avatar} alt={testimonials[5].name} />
            </button>
          </div>

          <div className="profile right-bottom">
            <button onClick={() => setActiveTestimonial(testimonials[6])} className="profile-btn medium">
              <img src={testimonials[6].avatar} alt={testimonials[6].name} />
            </button>
          </div>

          <div className="profile bottom">
            <button onClick={() => setActiveTestimonial(testimonials[7])} className="profile-btn small">
              <img src={testimonials[7].avatar} alt={testimonials[7].name} />
            </button>
          </div>
        </div>

        <div className="featured">
          <div className="avatar-wrap">
            <div className="avatar-border">
              <div className="avatar-inner">
                <img src={activeTestimonial.avatar} alt={activeTestimonial.name} />
              </div>
            </div>
          </div>

          <h3>{activeTestimonial.name}</h3>
          <p>
            {activeTestimonial.location}, {activeTestimonial.date}
          </p>
          <div className="stars">{renderStars(activeTestimonial.rating)}</div>
          <blockquote>{activeTestimonial.text}</blockquote>
        </div>
      </div>
    </section>
  )
}
