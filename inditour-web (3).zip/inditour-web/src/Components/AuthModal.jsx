import React, { useState } from "react";

const AuthModal = ({ show, onClose }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name : "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "USER",
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  if (!show) return null;

  // Handle input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle Login
  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      console.log("going in this")
      const res = await fetch(
        "https://api.inditour.com/api/v1/user/login",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: formData.email,
            password: formData.password,
            confirmPassword: formData.confirmPassword,
          }),
        }
      );
      // console.log(res,"the data is")

      const data = await res.json();
      console.log(data,"the data is")
       if (data.success) {
        console.log("login successful")
        setMessage("✅ Login successful!");
        localStorage.setItem("user", JSON.stringify(data.data));
        onClose();
      } else {
        setMessage(data.message || "❌ Login failed!");
      }
    } catch (err) {
      setMessage("❌ Something went wrong!");
    }
    setLoading(false);
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      const res = await fetch(
        "https://api.inditour.com/api/v1/user",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: formData.name ,
            email: formData.email,
            password: formData.password,
            role: formData.role,
            confirmPassword: formData.confirmPassword,
          }),
        }
      );

      const data = await res.json();
      if (res.ok) {
        setMessage("✅ Signup successful! Please login.");
        setIsLogin(true);
      } else {
        setMessage(data.message || "❌ Signup failed!");
      }
    } catch (err) {
      setMessage("❌ Something went wrong!");
    }
    setLoading(false);
  };

  return (
    <div className="modal fade show" style={{ display: "block" }}>
      <div className="modal-dialog modal-dialog-centered modal-dialog-scrollable rt-lgoinmodal _ad_login">
        <div className="modal-content">
          <div className="modal-body position-relative">
            <div className="rt-modal-headr rt-mb-20 text-center">
              <img
                src="https://server1.pearl-developer.com/inditour/public/app/website-info/logo/indi-logo.png"
                alt="modal logo"
                draggable="false"
              />
              {isLogin ? (
                <>
                  <h4>Login in to Inditour</h4>
                  <p>Log in to get updates on the things that interest you.</p>
                </>
              ) : (
                <>
                  <h4>Create your Account</h4>
                  <p>Sign up to get updates on the things that interest you.</p>
                </>
              )}
            </div>

            {/* Login Form */}
            {isLogin ? (
              <div className="rt-modal-input one">
                <form className="rt-form" onSubmit={handleLogin}>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="form-control pill rt-mb-15"
                    placeholder="Email"
                    required
                  />
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className="form-control pill rt-mb-15"
                    placeholder="Password"
                    required
                  />
                  <input
                    type="submit"
                    disabled={loading}
                    className="rt-btn rt-gradient pill d-block text-uppercase"
                    value={loading ? "Logging in..." : "Log In"}
                  />
                </form>
                <div className="ac-register text-center mt-3">
                  <span>
                    Don’t have an account?{" "}
                    <button
                      type="button"
                      onClick={() => setIsLogin(false)}
                      className="btn btn-link p-0"
                    >
                      Sign Up Now <i className="icofont-double-right"></i>
                    </button>
                  </span>
                </div>
              </div>
            ) : (
              // Signup Form
              <div className="rt-modal-input two">
                <form className="rt-form" onSubmit={handleSignup}>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="form-control pill rt-mb-15"
                    placeholder="User name"
                    required
                  />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="form-control pill rt-mb-15"
                    placeholder="Enter your email"
                    required
                  />
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className="form-control pill rt-mb-15"
                    placeholder="Password"
                    required
                  />
                  <input
                    type="password"
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    className="form-control pill rt-mb-15"
                    placeholder="Confirm Password"
                    required
                  />
                  <input
                    type="submit"
                    disabled={loading}
                    className="rt-btn rt-gradient pill d-block text-uppercase"
                    value={loading ? "Signing up..." : "Sign Up"}
                  />
                </form>
                <div className="ac-register text-center mt-3">
                  <span>
                    Already have an account?{" "}
                    <button
                      type="button"
                      onClick={() => setIsLogin(true)}
                      className="btn btn-link p-0"
                    >
                      LOGIN <i className="icofont-double-right"></i>
                    </button>
                  </span>
                </div>
              </div>
            )}

            {/* API response messages */}
            {message && <p className="text-center mt-2">{message}</p>}

            <div className="rt-modal-footer text-center mt-4">
              <span>Or</span>
              <h4>Sign Up with social media</h4>
              <ul className="rt-social rt-circle-style2">
                <li>
                  <a href="#">
                    <i className="fa-brands fa-facebook"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-twitter"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa-brands fa-linkedin"></i>
                  </a>
                </li>
              </ul>
            </div>

            <button
              type="button"
              className="btn-close position-absolute top-0 end-0 m-3"
              onClick={onClose}
            ></button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
