import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import AuthModal from "./AuthModal";

const Header = () => {
  const [showSearch, setShowSearch] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false); 
  const location = useLocation();

  // --------- check login on mount ----------
  useEffect(() => {
    const token = localStorage.getItem("token");
    setIsAuthenticated(!!token);
  }, []);

  // --------- handle logout ----------
  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsAuthenticated(false);
  };

  // --------- google translate -----------
  useEffect(() => {
    if (!document.querySelector("#google-translate-script")) {
      const addScript = document.createElement("script");
      addScript.id = "google-translate-script";
      addScript.src =
        "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      document.body.appendChild(addScript);
    }
    window.googleTranslateElementInit = () => {
      new window.google.translate.TranslateElement(
        {
          pageLanguage: "en",
          includedLanguages: "en,hi,fr,es,de,zh-CN",
          layout: window.google.translate.TranslateElement.InlineLayout.SIMPLE,
        },
        "google_translate_element"
      );
    };
  }, []);

  // --------- header logo -----------
  const homeLogo =
    "https://server1.pearl-developer.com/inditour/public/app/website-info/logo/indi-logo.png";
  const innerLogo =
    "https://server1.pearl-developer.com/inditour/public/app/website-info/logo/indi-logo.png";

  useEffect(() => {
    const handleScroll = () => {
      const header = document.querySelector(".rt-sticky");
      if (window.scrollY > 50) {
        header?.classList.add("rt-sticky-active");
      } else {
        header?.classList.remove("rt-sticky-active");
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const isHomePage = location.pathname === "/";

  return (
    <>
      <header className="rt-site-header rt-fixed-top white-menu">
        <div className="top-header">
          <div className="container">
            <div className="row align-items-center">
              <div className="col-lg-4 col-md-5 col-sm-6 d-none d-sm-block">
                <ul className="list-inline mb-0">
                  <li className="list-inline-item me-3">
                    <i className="icofont-headphone-alt"></i> Support
                  </li>
                  <li className="list-inline-item">
                    <a
                      href="mailto:info@inditour.com"
                      className="text-decoration-none"
                    >
                      <i className="icofont-email"></i> info@inditour.com
                    </a>
                  </li>
                </ul>
              </div>

              <div className="col-lg-8 col-md-7 col-sm-6 col-12 p-sm-0 text-md-right">
                <ul className="top-social text-end">
                  <li className="_ad_google">
                    <i className="fa-solid fa-globe"></i>
                    <div id="google_translate_element"></div>
                  </li>

                  {!isAuthenticated ? (
                    <li>
                      <a
                        href="#"
                        className="text-decoration-none"
                        onClick={() => setShowModal(true)}
                      >
                        <i className="far fa-user-circle"></i> Sign in | Join
                      </a>
                    </li>
                  ) : (
                    <li className="nav-item dropdown">
                      <a
                        href="#"
                        className="dropdown-toggle text-decoration-none"
                        id="profileDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        <i className="far fa-user-circle"></i> Ashish Verma
                      </a>
                      <ul className="dropdown-menu profileDropdown" aria-labelledby="profileDropdown">
                        <li>
                          <NavLink to="/profile" className="dropdown-item">
                            My Profile
                          </NavLink>
                        </li>
                        <li>
                          <NavLink to="/dashboard" className="dropdown-item">
                            Dashboard
                          </NavLink>
                        </li>
                        <li>
                          <NavLink to="/my-bookings" className="dropdown-item">
                            My Bookings
                          </NavLink>
                        </li>
                        <li>
                          <button className="dropdown-item" onClick={handleLogout}>
                            Logout
                          </button>
                        </li>
                      </ul>
                    </li>
                  )}

                  <span className="d-lg-inline">
                    <li>
                      <div className="d-flex align-items-center _ad_contact">
                        <span className="d-md-inline">
                          <NavLink
                            to="/contact-us"
                            className="rt-btn rt-gradient2 rt-rounded text-uppercase rt-Bshadow-1"
                          >
                            Contact Us
                          </NavLink>
                        </span>
                      </div>
                    </li>
                  </span>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="main-header rt-sticky">
          <nav className="navbar">
            <div className="container">
              <a
                href="/"
                className={`brand-logo site-logo ${
                  isHomePage ? "homepage-logo" : "innerpage-logo"
                }`}
              >
                <img src={isHomePage ? homeLogo : innerLogo} alt="Logo" />
              </a>

              <a
                href="/"
                className={`sticky-logo site-logo ${
                  isHomePage ? "homepage-logo" : "innerpage-logo"
                }`}
              >
                <img src={isHomePage ? homeLogo : innerLogo} alt="Logo" />
              </a>

              <div className="ml-auto d-flex align-items-center">
                <div className="main-menu _ad_menu">
                  <ul>
                    <li className="current-menu-item">
                      <a href="/">Home</a>
                    </li>
                    <li>
                      <a href="/trip-package">Trip package</a>
                    </li>
                    <li>
                      <a href="/pocket-trips">Pocket Trips</a>
                    </li>
                    <li>
                      <a href="/service">Services</a>
                    </li>
                    <li>
                      <a href="/about">About</a>
                    </li>
                    <li>
                      <a href="/blog">Blog</a>
                    </li>
                  </ul>
                  <form className="form-inline _ad_contact">
                    <input
                      className={`form-control mr-sm-2 header_search ${
                        showSearch ? "d-block" : "d-none"
                      } d-md-inline-block`}
                      type="search"
                      placeholder="Search..."
                      aria-label="Search"
                    />
                    <button
                      className="btn rt-btn rt-gradient2 rt-rounded text-uppercase rt-Bshadow-1 searchBtn_desk d-md-inline-block d-none"
                      type="submit"
                    >
                      Search
                    </button>
                    <button
                      type="button"
                      id="toggleSearch"
                      className="mobile_searchBtn d-md-none"
                      onClick={() => setShowSearch(!showSearch)}
                    >
                      <i className="fa-solid fa-magnifying-glass"></i>
                    </button>
                  </form>
                </div>

                {/* ===== Mobile Menu Trigger ===== */}
                <div className="mobile-menu d-lg-none">
                  <div
                    className="menu-click"
                    type="button"
                    data-bs-toggle="offcanvas"
                    data-bs-target="#mobileOffcanvas"
                    aria-controls="mobileOffcanvas"
                  >
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>

      {/* ===== Offcanvas ===== */}
      <div
        className="offcanvas offcanvas-start"
        tabIndex="-1"
        id="mobileOffcanvas"
        aria-labelledby="mobileOffcanvasLabel"
      >
        <div className="offcanvas-header">
          <h5 id="mobileOffcanvasLabel">Menu</h5>
          <button
            type="button"
            className="btn-close text-reset"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div className="offcanvas-body">
          <ul className="list-unstyled">
            <li>
              <a href="/">Home</a>
            </li>
            <li>
              <a href="/trip-package">Trip Package</a>
            </li>
            <li>
              <a href="/pocket-trips">Pocket Trips</a>
            </li>
            <li>
              <a href="/service">Services</a>
            </li>
            <li>
              <a href="/about">About</a>
            </li>
            <li>
              <a href="/blog">Blog</a>
            </li>
            <li>
              <a href="/contact-us">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>

      {/* Auth Modal */}
      <AuthModal
        show={showModal}
        onClose={() => {
          setShowModal(false);
          const token = localStorage.getItem("token");
          if (token) setIsAuthenticated(true); 
        }}
      />
    </>
  );
};

export default Header;
